# AETHER CLASH: LEGENDS OF KI — base jugable (Godot 4.3)

## Cómo obtener el APK con GitHub (sin instalar nada en tu PC)

1. Crea una cuenta en https://github.com si no tienes.
2. Crea un repositorio nuevo (botón **New**), nombre p. ej. `aether-clash`, déjalo **vacío**.
3. Sube el contenido de esta carpeta **descomprimida** (que incluya la carpeta oculta `.github`):
   - Con Git (recomendado, conserva `.github`):
     ```
     cd aether-clash
     git init
     git add .
     git commit -m "Primera version"
     git branch -M main
     git remote add origin https://github.com/TU_USUARIO/aether-clash.git
     git push -u origin main
     ```
   - O desde la web: *Add file → Upload files* y arrastra TODO (si no aparece `.github/workflows/build-apk.yml`, créalo con *Add file → Create new file* copiando su contenido).
4. Abre la pestaña **Actions**. Si pide habilitar workflows, acéptalo.
5. El workflow **Build Android APK** se ejecuta solo con cada push. También puedes lanzarlo a mano: *Actions → Build Android APK → Run workflow*.
6. Cuando termine (unos 5–10 min, círculo verde), entra al run y descarga **aether-clash-apk** (sección *Artifacts*). Dentro está `aether-clash.apk`.
7. Pásalo al teléfono, ábrelo y permite "instalar apps de orígenes desconocidos". Es un APK **debug** firmado con una clave de depuración (instalable, no apto para Play Store).

Si el run falla (círculo rojo), abre el paso que falló y copia el error: lo más probable es un detalle de ruta del SDK/JDK en el contenedor o un error de script de Godot (no pude ejecutar Godot aquí).

## Probar el multijugador LAN (2 teléfonos)
- Teléfono A: MULTIJUGADOR LAN → CREAR PARTIDA (muestra su IP). Puede ser el punto de acceso Wi-Fi del propio A, o ambos en el mismo Wi-Fi.
- Teléfono B: BUSCAR PARTIDAS LOCALES, o escribe la IP de A y CONECTAR POR IP.
- B elige personaje y pulsa LISTO; A pulsa INICIAR.
- Si no se ven, el router/hotspot probablemente aísla clientes: usa IP manual u otra red.
- Puertos: juego UDP 24565, descubrimiento UDP 24566.

## Controles (estilo Sparking Zero)
Táctil: joystick flotante en la mitad izquierda y botones:
- **GOLPE**: combo ligero de 5 golpes con "imán" hacia el rival (mantén pulsado para encadenar). El 5.º lanza al rival.
- **FUERTE**: golpe pesado con breve carga; lanza lejos y rompe la guardia. Si atacas desde arriba, el rival sale disparado hacia abajo.
- **KI**: ráfaga teledirigida (mantén para disparar en serie).
- **GUARDIA**: bloqueo; justo al pulsarla (0,2 s) es contraataque perfecto. GUARDIA + GOLPE = contragolpe (media barra de ki).
- **DASH**: Z-Burst. Con el stick: ráfaga en esa dirección; sin stick: embestida hacia el rival que termina en golpe. Con GUARDIA pulsada: desplazamiento tras el rival. Justo después de lanzar al rival: persecución instantánea para seguir el combo. Estando lanzado (tras 0,3 s) o con GUARDIA: recuperación aérea.
- **SPARKING**: una vez por combate (1 barra de ki): 18 s de más daño, velocidad y regeneración de energía.
- **ULTI** (2 barras de ki), **SUBIR/BAJAR** (vuelo), **CARGA** (cargar ki).
Física: movimiento con inercia (derrape en el aire), inclinación del cuerpo, congelado al impactar, sacudida de cámara, rebotes contra paredes/suelo/rocas (daño extra y rocas que se rompen).
Teclado (pruebas en PC): WASD, Espacio/Ctrl subir/bajar, J golpe, H fuerte, K ki, L guardia, I dash, O carga, U ulti, P sparking.

## Estado real (honesto)
**Sin probar**: este código se escribió sin poder ejecutar Godot ni exportar. Puede tener errores de script que hay que corregir en la primera ejecución. No se probó en teléfonos reales ni con 2 dispositivos.

**Implementado (código):** menú principal con fondo 3D, gestor de pantallas, selección/visor 3D de 10 personajes (clases con estadísticas distintas, gigante y terrestre sin vuelo), combate 3D con fijación de objetivo y cámara, vuelo real (subir/bajar), combo de 4 golpes, ráfagas con rastreo, ulti, carga de energía y agotamiento, guardia con contraataque perfecto y ruptura, desplazamiento instantáneo, 5 arenas (rocas destruibles y caída fuera), IA de 5 niveles, Historia (5 capítulos con rama), Combate, Entrenamiento, Torneo (3 rondas), Supervivencia, Combates personalizados (plantillas + guardado JSON versionado), Configuración (calidad/FPS/controles), guardado local, LAN con ENet (host autoritativo, snapshots a 20 Hz, descubrimiento UDP + IP manual).

**Pendiente:** modelos y animaciones esqueléticas reales (los luchadores son figuras primitivas), audio/música, transformaciones, fusiones, equipos y relevos, choques de energía/QTE, recuperación en el aire, editor avanzado de condiciones, exportar/compartir combates por LAN, personalización de atuendos, predicción/reconciliación en LAN (el invitado ve la partida con la latencia de red), LOD/pooling, pruebas con 2 teléfonos físicos.


## Cambios: física de vuelo + mapas
- **Bug corregido**: el control táctil enviaba un `intent` sin las claves `heavy` y `spark`, lo que hacía fallar el simulador cada frame (el vuelo y otras acciones no respondían). Ahora siempre existen.
- **Vuelo 3D nuevo** (`fighter.gd`): SUBIR despega con impulso y te mantiene flotando (sin gravedad); el stick hacia adelante vuela hacia el rival incluyendo la altura; la velocidad se acumula al volar sostenido; girar derrapa por inercia; soltar el stick frena deslizando; el Z-Burst conserva impulso al terminar. El cuerpo se inclina según la trayectoria 3D y hay estelas a máxima velocidad.
- **Cámara**: más pausada en vuelo, anticipa el movimiento y abre el FOV con la velocidad.
- **Mapas**: cada arena usa `assets/sky_N.png` (cielo panorámico) y `assets/ground_N.png` (suelo/rocas). Inspirados en escenarios tipo Sparking Zero (yermo, desierto, ciudad neón, volcán, arena en las nubes). Se generan con `python3 tools/gen_maps.py` (puedes reemplazar los PNG por los que quieras con el mismo nombre).


## Mejoras LAN y controles (edición)

- El multijugador utiliza ENet sobre UDP y descubrimiento local por broadcast; no necesita conexión a internet.
- Conecta ambos dispositivos a la misma Wi-Fi o al mismo hotspot. Si el descubrimiento automático no encuentra la sala, escribe la IP local del anfitrión.
- Puertos UDP utilizados: **24565** (partida) y **24566** (descubrimiento). Algunos routers/hotspots activan aislamiento entre clientes; desactívalo si no conecta.
- En **Configuración**, activa **Editar posición de botones** y guarda. Durante un combate táctil, arrastra cada botón a su nueva posición. El tamaño y la transparencia también se guardan.
- Se añadieron estelas de ki, partículas al cargar energía y efectos de impacto; se conservaron los sistemas existentes de movimiento, combate, colisiones y animación.
- Para compilar, sube el contenido de esta carpeta a tu repositorio GitHub y ejecuta el workflow de GitHub Actions incluido en `.github/workflows/build-apk.yml`.
