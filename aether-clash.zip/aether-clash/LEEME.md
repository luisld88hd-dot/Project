# AETHER CLASH: LEGENDS OF KI — base jugable (Godot 4.3)

## Cómo obtener el APK con GitHub (sin instalar nada en tu PC)

1. Crea una cuenta en https://github.com si no tienes.
2. Crea un repositorio nuevo (botón **New**), nombre p. ej. `aether-clash`, déjalo **vacío**.
3. Sube el contenido de esta carpeta **descomprimida** (que incluya la carpeta oculta `.github`):
   - Con Git (recomendado, conserva `.github`):
     ```
     cd aether-clash
     git init
     git add .
     git commit -m "Primera version"
     git branch -M main
     git remote add origin https://github.com/TU_USUARIO/aether-clash.git
     git push -u origin main
     ```
   - O desde la web: *Add file → Upload files* y arrastra TODO (si no aparece `.github/workflows/build-apk.yml`, créalo con *Add file → Create new file* copiando su contenido).
4. Abre la pestaña **Actions**. Si pide habilitar workflows, acéptalo.
5. El workflow **Build Android APK** se ejecuta solo con cada push. También puedes lanzarlo a mano: *Actions → Build Android APK → Run workflow*.
6. Cuando termine (unos 5–10 min, círculo verde), entra al run y descarga **aether-clash-apk** (sección *Artifacts*). Dentro está `aether-clash.apk`.
7. Pásalo al teléfono, ábrelo y permite "instalar apps de orígenes desconocidos". Es un APK **debug** firmado con una clave de depuración (instalable, no apto para Play Store).

Si el run falla (círculo rojo), abre el paso que falló y copia el error: lo más probable es un detalle de ruta del SDK/JDK en el contenedor o un error de script de Godot (no pude ejecutar Godot aquí).

## Probar el multijugador LAN (2 teléfonos)
- Teléfono A: MULTIJUGADOR LAN → CREAR PARTIDA (muestra su IP). Puede ser el punto de acceso Wi-Fi del propio A, o ambos en el mismo Wi-Fi.
- Teléfono B: BUSCAR PARTIDAS LOCALES, o escribe la IP de A y CONECTAR POR IP.
- B elige personaje y pulsa LISTO; A pulsa INICIAR.
- Si no se ven, el router/hotspot probablemente aísla clientes: usa IP manual u otra red.
- Puertos: juego UDP 24565, descubrimiento UDP 24566.

## Controles
Táctil: joystick flotante en la mitad izquierda; botones GOLPE, KI, GUARDIA, SALTO (aparecer detrás del rival), ULTI (necesita 2 cargas de KI), SUBIR/BAJAR (vuelo), CARGA.
Teclado (pruebas en PC): WASD, Espacio/Ctrl subir/bajar, J golpe, K ki, L guardia, I salto, O carga, U ulti.

## Estado real (honesto)
**Sin probar**: este código se escribió sin poder ejecutar Godot ni exportar. Puede tener errores de script que hay que corregir en la primera ejecución. No se probó en teléfonos reales ni con 2 dispositivos.

**Implementado (código):** menú principal con fondo 3D, gestor de pantallas, selección/visor 3D de 10 personajes (clases con estadísticas distintas, gigante y terrestre sin vuelo), combate 3D con fijación de objetivo y cámara, vuelo real (subir/bajar), combo de 4 golpes, ráfagas con rastreo, ulti, carga de energía y agotamiento, guardia con contraataque perfecto y ruptura, desplazamiento instantáneo, 5 arenas (rocas destruibles y caída fuera), IA de 5 niveles, Historia (5 capítulos con rama), Combate, Entrenamiento, Torneo (3 rondas), Supervivencia, Combates personalizados (plantillas + guardado JSON versionado), Configuración (calidad/FPS/controles), guardado local, LAN con ENet (host autoritativo, snapshots a 20 Hz, descubrimiento UDP + IP manual).

**Pendiente:** modelos y animaciones esqueléticas reales (los luchadores son figuras primitivas), audio/música, transformaciones, fusiones, equipos y relevos, choques de energía/QTE, recuperación en el aire, editor avanzado de condiciones, exportar/compartir combates por LAN, personalización de atuendos, predicción/reconciliación en LAN (el invitado ve la partida con la latencia de red), LOD/pooling, pruebas con 2 teléfonos físicos.
