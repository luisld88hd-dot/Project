extends Node

# mode: 1 = combate normal, 0 = solo defiende, -1 = pasivo (entrenamiento)
var f = null
var level := 2
var mode := 1
var _think := 0.0
var _strafe := 1.0
var _attack_hold := false


func _physics_process(delta: float) -> void:
    if f == null or not is_instance_valid(f) or f.dead:
        return
    if mode == -1:
        return
    if f.target == null or not is_instance_valid(f.target) or f.target.dead:
        f.intent["move"] = Vector2.ZERO
        return
    if _attack_hold:
        f.intent["attack"] = true
    _think -= delta
    if _think <= 0.0:
        var lv := clampi(level, 0, 4)
        _think = [0.9, 0.6, 0.4, 0.25, 0.15][lv] * randf_range(0.8, 1.2)
        _decide(lv)


func _decide(lv: int) -> void:
    var it: Dictionary = f.intent
    var t = f.target
    var d: Vector3 = t.global_position - f.global_position
    var dy := d.y
    d.y = 0.0
    var dist := d.length()
    it["move"] = Vector2.ZERO
    it["up"] = 0.0
    it["guard"] = false
    it["charge"] = false
    _attack_hold = false
    if mode == 0:
        it["guard"] = true
        return
    if f.can_fly:
        if dy > 1.2:
            it["up"] = 1.0
        elif dy < -1.2:
            it["up"] = -1.0
    var guard_p: float = [0.0, 0.1, 0.25, 0.4, 0.6][lv]
    if t.atk_cd > 0.1 and dist < 4.5 and randf() < guard_p:
        it["guard"] = true
        return
    if f.energy < 18.0 and dist > 9.0:
        it["charge"] = true
        return
    if f.ki_meter >= 200.0 and lv >= 3 and dist > 5.0:
        it["ult"] = true
    if dist > 13.0:
        it["move"] = Vector2(0, -1)
        if lv >= 1 and randf() < 0.5:
            it["blast"] = true
        if lv >= 2 and randf() < 0.3:
            it["dash"] = true
    elif dist > 3.4:
        it["move"] = Vector2(_strafe * 0.5, -1.0)
        if lv >= 1 and randf() < 0.35:
            it["blast"] = true
    else:
        if randf() < 0.4 + 0.12 * lv:
            _attack_hold = true
            it["attack"] = true
        else:
            it["move"] = Vector2(_strafe, 0.8)
    if randf() < 0.2:
        _strafe = -_strafe
