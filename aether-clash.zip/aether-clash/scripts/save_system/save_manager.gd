extends Node

const SAVE_PATH := "user://save.json"
const CUSTOM_DIR := "user://custom"
const VERSION := 1

var data: Dictionary = {}

func _ready() -> void:
    load_data()

func defaults() -> Dictionary:
    return {
        "version": VERSION,
        "story_progress": 0,
        "branch": "mercy",
        "settings": {"quality": 1, "fps": 60, "btn_scale": 1.0, "opacity": 0.7, "edit_controls": false, "button_positions": {}},
        "stats": {"wins": 0, "losses": 0, "best_wave": 0}
    }

func load_data() -> void:
    data = defaults()
    if not FileAccess.file_exists(SAVE_PATH):
        return
    var f := FileAccess.open(SAVE_PATH, FileAccess.READ)
    if f == null:
        return
    var parsed = JSON.parse_string(f.get_as_text())
    if typeof(parsed) != TYPE_DICTIONARY or int(parsed.get("version", 0)) != VERSION:
        return
    for k in data.keys():
        if not parsed.has(k):
            continue
        if typeof(data[k]) == TYPE_DICTIONARY:
            if typeof(parsed[k]) != TYPE_DICTIONARY:
                continue
            for kk in data[k].keys():
                if parsed[k].has(kk) and typeof(parsed[k][kk]) == typeof(data[k][kk]):
                    data[k][kk] = parsed[k][kk]
        elif typeof(parsed[k]) == typeof(data[k]):
            data[k] = parsed[k]

func save() -> void:
    var f := FileAccess.open(SAVE_PATH, FileAccess.WRITE)
    if f:
        f.store_string(JSON.stringify(data))

func list_custom() -> Array:
    var out: Array = []
    DirAccess.make_dir_recursive_absolute(CUSTOM_DIR)
    var d := DirAccess.open(CUSTOM_DIR)
    if d == null:
        return out
    for fn in d.get_files():
        if fn.ends_with(".json"):
            var f := FileAccess.open(CUSTOM_DIR + "/" + fn, FileAccess.READ)
            if f == null:
                continue
            var p = JSON.parse_string(f.get_as_text())
            if typeof(p) == TYPE_DICTIONARY and int(p.get("version", 0)) == VERSION and p.has("cfg"):
                p["file"] = fn
                out.append(p)
    return out

func save_custom(title: String, cfg: Dictionary) -> void:
    DirAccess.make_dir_recursive_absolute(CUSTOM_DIR)
    var fn := "c_%d.json" % int(Time.get_unix_time_from_system())
    var f := FileAccess.open(CUSTOM_DIR + "/" + fn, FileAccess.WRITE)
    if f:
        f.store_string(JSON.stringify({"version": VERSION, "title": title, "cfg": cfg}))

func delete_custom(fn: String) -> void:
    DirAccess.remove_absolute(CUSTOM_DIR + "/" + fn)
