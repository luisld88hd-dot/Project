extends Node3D

signal finished(action: String)

const FighterScript = preload("res://scripts/fighters/fighter.gd")
const AIScript = preload("res://scripts/ai/ai_controller.gd")
const TouchScript = preload("res://scripts/ui/touch_controls.gd")
const HudScript = preload("res://scripts/ui/battle_hud.gd")

var cfg: Dictionary = {}
var arena_def: Dictionary = {}
var quality := 1
var online := false
var is_host := true
var fa = null      # luchador A (anfitrión / jugador 1)
var fb = null      # luchador B (rival / invitado)
var player = null  # el que controla este teléfono
var enemy = null
var ai = null
var cam: Camera3D
var hud
var touch
var time_left := 99.0
var over := false
var wave := 1
var _tick := 0
var _remote: Dictionary = {}
var _remote_counts := {"attack": 0, "heavy": 0, "blast": 0, "dash": 0, "ult": 0, "spark": 0}
var _shake := 0.0
var _snap: Dictionary = {}


func _ready() -> void:
    cfg = GameManager.battle_config
    quality = int(SaveManager.data["settings"]["quality"])
    online = bool(cfg.get("online", false)) and NetworkManager.online
    is_host = (not online) or NetworkManager.is_host
    arena_def = GameManager.ARENAS[clampi(int(cfg["arena"]), 0, GameManager.ARENAS.size() - 1)]
    time_left = float(cfg["time"])
    wave = int(cfg["wave"])
    _build_arena()
    _build_fighters()
    _build_camera()
    _build_ui()
    if online:
        NetworkManager.fx_received.connect(_on_fx)
        NetworkManager.disconnected.connect(_on_disconnected)
        if is_host:
            NetworkManager.input_received.connect(func(d): _remote = d)
        else:
            NetworkManager.snapshot_received.connect(func(d): _snap = d)
    hud.show_message(_intro_text(), 2.0)


func _exit_tree() -> void:
    get_tree().paused = false


func _intro_text() -> String:
    match str(cfg["mode"]):
        "training": return "ENTRENAMIENTO"
        "survival": return "OLEADA %d" % wave
        "tournament": return "TORNEO - RONDA %d/3" % int(cfg["round"])
        "story": return str(GameManager.STORY[int(cfg["chapter"])]["title"])
    return "¡COMBATE!"


# ------------------------------------------------------------ construcción
func _build_arena() -> void:
    var env := Environment.new()
    var sky := Sky.new()
    var sm := ProceduralSkyMaterial.new()
    sm.sky_top_color = arena_def["sky_top"]
    sm.sky_horizon_color = arena_def["sky_hor"]
    sm.ground_horizon_color = arena_def["sky_hor"]
    sm.ground_bottom_color = Color("#2f7a30")
    var ai_idx := clampi(int(cfg["arena"]), 0, GameManager.ARENAS.size() - 1)
    var sky_tex = load("res://assets/sky_%d.png" % ai_idx)
    if sky_tex != null:
        var pm := PanoramaSkyMaterial.new()
        pm.panorama = sky_tex
        sky.sky_material = pm
    else:
        sky.sky_material = sm
    env.background_mode = Environment.BG_SKY
    env.sky = sky
    env.ambient_light_source = Environment.AMBIENT_SOURCE_SKY
    var we := WorldEnvironment.new()
    we.environment = env
    add_child(we)
    var sun := DirectionalLight3D.new()
    sun.rotation_degrees = Vector3(-50, 30, 0)
    sun.shadow_enabled = quality > 0
    add_child(sun)
    var ring: bool = arena_def["ringout"]
    var radius := 24.0 if ring else 60.0
    var ground := StaticBody3D.new()
    var cs := CollisionShape3D.new()
    var shape := CylinderShape3D.new()
    shape.radius = radius
    shape.height = 2.0
    cs.shape = shape
    cs.position.y = -1.0
    ground.add_child(cs)
    var mi := MeshInstance3D.new()
    var cm := CylinderMesh.new()
    cm.top_radius = radius
    cm.bottom_radius = radius
    cm.height = 2.0
    mi.mesh = cm
    var mat := StandardMaterial3D.new()
    mat.albedo_color = Color.WHITE
    mat.roughness = 0.95
    var ground_tex = load("res://assets/ground_%d.png" % ai_idx)
    if ground_tex != null:
        _apply_tex(mat, ground_tex, ai_idx)
    else:
        mat.albedo_color = arena_def["ground"]
    mi.material_override = mat
    mi.position.y = -1.0
    ground.add_child(mi)
    add_child(ground)
    if arena_def["rocks"]:
        var rng := RandomNumberGenerator.new()
        rng.seed = 1234 + int(cfg["arena"])
        for i in range(14):
            var ang := rng.randf() * TAU
            var dist := rng.randf_range(12.0, 40.0)
            var sz := rng.randf_range(1.5, 4.0)
            var rock := StaticBody3D.new()
            rock.position = Vector3(cos(ang) * dist, sz * 0.5, sin(ang) * dist)
            rock.set_meta("destructible", true)
            var rcs := CollisionShape3D.new()
            var bs := BoxShape3D.new()
            bs.size = Vector3(sz, sz, sz)
            rcs.shape = bs
            rock.add_child(rcs)
            var rm := MeshInstance3D.new()
            var bm := BoxMesh.new()
            bm.size = Vector3(sz, sz, sz)
            rm.mesh = bm
            var rmat := StandardMaterial3D.new()
            rmat.albedo_color = Color("#8a8a92")
            if ground_tex != null:
                _apply_tex(rmat, ground_tex, ai_idx)
                rmat.albedo_color = Color(0.75, 0.75, 0.78)
            rm.material_override = rmat
            rock.add_child(rm)
            add_child(rock)


# Textura PNG en coordenadas de mundo (triplanar): se ve bien en el cilindro y en las rocas.
func _apply_tex(m: StandardMaterial3D, tex: Texture2D, idx: int) -> void:
    m.albedo_texture = tex
    m.uv1_triplanar = true
    m.uv1_world_triplanar = true
    m.uv1_scale = Vector3.ONE * 0.1
    m.texture_filter = BaseMaterial3D.TEXTURE_FILTER_LINEAR_WITH_MIPMAPS_ANISOTROPIC
    var glow: float = [0.0, 0.0, 0.8, 1.0, 0.0][clampi(idx, 0, 4)]   # neon de la ciudad / lava del volcán
    if glow > 0.0:
        m.emission_enabled = true
        m.emission_texture = tex
        m.emission_energy_multiplier = glow


func _spawn(idx: int, pos: Vector3, team: int, hp_mult: float):
    var f = FighterScript.new()
    f.apply_character(GameManager.CHARACTERS[clampi(idx, 0, GameManager.CHARACTERS.size() - 1)], hp_mult)
    f.team = team
    f.ringout = arena_def["ringout"]
    f.arena_radius = 55.0
    f.position = pos
    add_child(f)
    return f


func _build_fighters() -> void:
    fa = _spawn(int(cfg["p_char"]), Vector3(0, 0.5, 7), 0, float(cfg["player_hp"]))
    fb = _spawn(int(cfg["e_char"]), Vector3(0, 0.5, -7), 1, float(cfg["enemy_hp"]))
    fa.target = fb
    fb.target = fa
    if online and not is_host:
        fa.puppet = true
        fb.puppet = true
        fa.puppet_pos = fa.position
        fb.puppet_pos = fb.position
        player = fb
        enemy = fa
    else:
        player = fa
        enemy = fb
    enemy.marked = true
    if str(cfg["mode"]) == "training":
        player.training = true
        enemy.training = true
    _hook_fighters()
    if not online:
        _make_ai()


func _hook_fighters() -> void:
    for f in [fa, fb]:
        f.died.connect(_on_died)
        f.message.connect(_on_message)
        f.impact.connect(_on_impact)
        if online and is_host:
            f.blast_fired.connect(func(o, d, b): NetworkManager.send_fx.rpc_id(NetworkManager.guest_id, "blast", {"idx": 0 if f == fa else 1, "o": o, "d": d, "big": b}))


func _make_ai() -> void:
    if ai != null:
        ai.queue_free()
    ai = AIScript.new()
    ai.f = enemy
    ai.level = int(cfg["level"])
    ai.mode = int(cfg["ai_mode"])
    add_child(ai)


func _build_camera() -> void:
    cam = Camera3D.new()
    cam.fov = 70.0
    cam.far = 400.0
    add_child(cam)
    cam.current = true
    var sgn := 1.0 if player == fa else -1.0
    cam.global_position = player.global_position + Vector3(0, 4, 10) * sgn
    cam.look_at(player.global_position + Vector3(0, 1.5, -6) * sgn, Vector3.UP)


func _build_ui() -> void:
    var layer := CanvasLayer.new()
    layer.layer = 10
    add_child(layer)
    touch = TouchScript.new()
    touch.fighter = player
    layer.add_child(touch)
    hud = HudScript.new()
    layer.add_child(hud)
    hud.action_pressed.connect(_on_action)
    hud.pause_requested.connect(_on_pause)


# ------------------------------------------------------------ bucle
func _physics_process(delta: float) -> void:
    if over:
        return
    var it: Dictionary = touch.get_intent()
    if not is_host:
        NetworkManager.send_input.rpc_id(1, {"move": it["move"], "up": it["up"], "guard": it["guard"], "charge": it["charge"], "counts": touch.counts.duplicate()})
        if not _snap.is_empty():
            fa.apply_state(_snap["a"])
            fb.apply_state(_snap["b"])
            time_left = float(_snap["t"])
        return
    player.intent = it
    if online:
        _apply_remote()
        _tick += 1
        if _tick % 3 == 0:
            NetworkManager.send_snapshot.rpc_id(NetworkManager.guest_id, {"a": fa.get_state(), "b": fb.get_state(), "t": time_left})
    if str(cfg["mode"]) == "training":
        enemy.hp = enemy.max_hp
    if time_left > 0.0 or float(cfg["time"]) <= 0.0:
        if float(cfg["time"]) > 0.0:
            time_left -= delta
    if float(cfg["time"]) > 0.0 and time_left <= 0.0:
        var pr: float = player.hp / player.max_hp
        var er: float = enemy.hp / enemy.max_hp
        _end(pr >= er, "TIEMPO AGOTADO")


func _apply_remote() -> void:
    if _remote.is_empty():
        return
    var d := _remote
    fb.intent["move"] = d["move"]
    fb.intent["up"] = d["up"]
    fb.intent["guard"] = d["guard"]
    fb.intent["charge"] = d["charge"]
    var c: Dictionary = d["counts"]
    for k in ["attack", "heavy", "blast", "dash", "ult", "spark"]:
        var n := int(c.get(k, 0))
        if n != int(_remote_counts[k]):
            fb.intent[k] = true
            _remote_counts[k] = n


func _process(delta: float) -> void:
    if player == null or enemy == null or cam == null:
        return
    var p_pos: Vector3 = player.global_position
    var e_pos: Vector3 = enemy.global_position
    var away := p_pos - e_pos
    away.y = 0.0
    if away.length() < 0.1:
        away = Vector3(0, 0, 1)
    away = away.normalized()
    var flat_dist := Vector2(p_pos.x - e_pos.x, p_pos.z - e_pos.z).length()
    var dist := clampf(flat_dist * 0.5 + 5.0, 6.0, 16.0)
    var side := away.cross(Vector3.UP) * 1.5
    var want := p_pos + away * dist + Vector3(0, 3.0 + maxf(0.0, (e_pos.y - p_pos.y) * 0.3), 0) + side
    # En vuelo la cámara se queda un poco atrás y anticipa el movimiento (sensación de velocidad)
    var pspeed: float = player.velocity.length()
    want += player.velocity * 0.06
    var follow := 4.2 if player.flying else 6.0
    cam.global_position = cam.global_position.lerp(want, clampf(1.0 - exp(-follow * delta), 0.0, 1.0))
    cam.look_at((p_pos + e_pos) * 0.5 + Vector3(0, 1.5, 0), Vector3.UP)
    # Sacudida por impacto y efecto de velocidad (FOV) en el DASH
    _shake = maxf(0.0, _shake - delta * 2.5)
    cam.h_offset = randf_range(-1.0, 1.0) * _shake * 0.35
    cam.v_offset = randf_range(-1.0, 1.0) * _shake * 0.35
    var dashing: bool = player.dash_time > 0.0
    var fov_t := 70.0 + clampf((pspeed - 10.0) * 0.5, 0.0, 8.0) + (12.0 if dashing else 0.0)
    cam.fov = lerpf(cam.fov, fov_t, clampf(delta * 6.0, 0.0, 1.0))
    hud.update_hud(player, enemy, time_left if float(cfg["time"]) > 0.0 else -1.0, _info_text())


func _info_text() -> String:
    match str(cfg["mode"]):
        "survival": return "OLEADA %d" % wave
        "tournament": return "RONDA %d/3" % int(cfg["round"])
        "story": return "CAPITULO %d" % (int(cfg["chapter"]) + 1)
        "training": return "ENTRENAMIENTO"
        "lan": return "LAN"
    return ""


# ------------------------------------------------------------ eventos
func _on_impact(strength: float) -> void:
    _shake = maxf(_shake, strength)


func _on_message(text: String) -> void:
    hud.show_message(text, 1.2)
    if online and is_host:
        NetworkManager.send_fx.rpc_id(NetworkManager.guest_id, "msg", {"t": text})


func _on_died(f) -> void:
    if not is_host or over:
        return
    if f == player:
        _end(false, "")
    else:
        _on_enemy_dead()


func _on_enemy_dead() -> void:
    if str(cfg["mode"]) == "survival":
        wave += 1
        SaveManager.data["stats"]["best_wave"] = maxi(int(SaveManager.data["stats"]["best_wave"]), wave - 1)
        player.hp = minf(player.max_hp, player.hp + player.max_hp * 0.25)
        player.energy = minf(player.max_energy, player.energy + 40.0)
        hud.show_message("OLEADA %d" % wave, 2.0)
        var old = enemy
        get_tree().create_timer(1.2).timeout.connect(func():
            if is_instance_valid(old):
                old.queue_free()
            if over:
                return
            var hp_mult := 1.0 + 0.25 * wave
            cfg["level"] = mini(4, 1 + wave / 2)
            enemy = _spawn(randi() % GameManager.CHARACTERS.size(), Vector3(0, 0.5, -7), 1, hp_mult)
            fb = enemy
            enemy.target = player
            player.target = enemy
            enemy.marked = true
            enemy.died.connect(_on_died)
            enemy.message.connect(_on_message)
            enemy.impact.connect(_on_impact)
            _make_ai())
        return
    _end(true, "")


func _end(win: bool, reason: String) -> void:
    if over:
        return
    over = true
    var mode := str(cfg["mode"])
    var sub := reason
    if online and is_host:
        NetworkManager.send_fx.rpc_id(NetworkManager.guest_id, "end", {"winner": 0 if win else 1, "reason": reason})
    var stats: Dictionary = SaveManager.data["stats"]
    var buttons: Array = []
    if mode == "survival":
        sub = "Oleadas superadas: %d" % (wave - 1)
        buttons = [["REINTENTAR", "retry", Color("#267CCB")], ["MENU", "menu", Color("#344B68")]]
        stats["best_wave"] = maxi(int(stats["best_wave"]), wave - 1)
        SaveManager.save()
        hud.show_overlay("FIN DE LA SUPERVIVENCIA", sub, buttons)
        return
    if win:
        stats["wins"] = int(stats["wins"]) + 1
        var nxt := GameManager.next_config(cfg)
        if mode == "story":
            var ch := int(cfg["chapter"])
            SaveManager.data["story_progress"] = maxi(int(SaveManager.data["story_progress"]), ch + 1)
            var st: Dictionary = GameManager.STORY[ch]
            if st.has("ending"):
                sub = str(st["ending"][str(SaveManager.data["branch"])])
        if mode == "tournament" and nxt.is_empty():
            sub = "¡CAMPEON DEL TORNEO!"
        if not nxt.is_empty():
            buttons.append(["SIGUIENTE COMBATE", "next", Color("#22A879")])
        if not online:
            buttons.append(["REVANCHA", "retry", Color("#267CCB")])
        buttons.append(["MENU", "menu", Color("#344B68")])
        SaveManager.save()
        hud.show_overlay("VICTORIA", sub, buttons)
    else:
        stats["losses"] = int(stats["losses"]) + 1
        SaveManager.save()
        if not online:
            buttons.append(["REINTENTAR", "retry", Color("#267CCB")])
        buttons.append(["MENU", "menu", Color("#344B68")])
        hud.show_overlay("DERROTA", sub, buttons)


func _on_fx(kind: String, d: Dictionary) -> void:
    if is_host:
        return
    match kind:
        "blast":
            var f = fa if int(d["idx"]) == 0 else fb
            f.spawn_projectile(d["o"], d["d"], 0.0, bool(d["big"]), true)
        "msg":
            hud.show_message(str(d["t"]), 1.2)
        "end":
            if over:
                return
            over = true
            var win := int(d["winner"]) == 1
            hud.show_overlay("VICTORIA" if win else "DERROTA", str(d["reason"]), [["MENU", "menu", Color("#344B68")]])


func _on_disconnected(reason: String) -> void:
    if over:
        return
    over = true
    hud.show_overlay("CONEXION PERDIDA", reason, [["MENU", "menu", Color("#344B68")]])


func _on_pause() -> void:
    if over:
        return
    if not online:
        get_tree().paused = true
    var b: Array = []
    if not online:
        b.append(["CONTINUAR", "resume", Color("#22A879")])
        b.append(["REINICIAR", "retry", Color("#267CCB")])
    else:
        b.append(["CONTINUAR", "resume", Color("#22A879")])
    b.append(["SALIR AL MENU", "menu", Color("#BC4F5D")])
    hud.show_overlay("PAUSA", "", b)


func _on_action(action: String) -> void:
    if action == "resume":
        get_tree().paused = false
        hud.clear_overlay()
        return
    get_tree().paused = false
    finished.emit(action)
