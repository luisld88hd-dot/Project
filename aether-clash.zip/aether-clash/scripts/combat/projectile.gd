extends Area3D

var owner_f = null
var target = null
var dir := Vector3.FORWARD
var dmg := 50.0
var big := false
var visual_only := false
var speed := 24.0
var life := 4.0
var _done := false


func setup(o, t, d: Vector3, dm: float, b: bool, vo: bool) -> void:
    owner_f = o
    target = t
    dir = d.normalized()
    dmg = dm
    big = b
    visual_only = vo
    if big:
        speed = 18.0


func _ready() -> void:
    var r := 0.4 * (2.4 if big else 1.0)
    var cs := CollisionShape3D.new()
    var sh := SphereShape3D.new()
    sh.radius = r
    cs.shape = sh
    add_child(cs)
    var mi := MeshInstance3D.new()
    var sm := SphereMesh.new()
    sm.radius = r
    sm.height = r * 2.0
    mi.mesh = sm
    var c := Color("#ffd24a") if big else Color("#5ad0ff")
    if owner_f != null and is_instance_valid(owner_f):
        c = owner_f.color.lightened(0.35)
    var m := StandardMaterial3D.new()
    m.albedo_color = c
    m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    mi.material_override = m
    add_child(mi)
    # Estela brillante del proyectil de ki.
    var trail := CPUParticles3D.new()
    trail.amount = 28 if big else 14
    trail.lifetime = 0.32 if big else 0.22
    trail.emitting = true
    trail.position = Vector3.ZERO
    trail.direction = Vector3.ZERO
    trail.spread = 180.0
    trail.initial_velocity_min = 0.2
    trail.initial_velocity_max = 1.2
    trail.gravity = Vector3.ZERO
    trail.scale_amount_min = 0.035
    trail.scale_amount_max = 0.12 if big else 0.07
    trail.color = c.lightened(0.5)
    var pm := ParticleProcessMaterial.new()
    pm.direction = Vector3.ZERO
    pm.spread = 180.0
    pm.initial_velocity_min = 0.2
    pm.initial_velocity_max = 1.2
    pm.gravity = Vector3.ZERO
    pm.scale_min = 0.035
    pm.scale_max = 0.12 if big else 0.07
    trail.process_material = pm
    add_child(trail)
    collision_layer = 0
    collision_mask = 1
    monitoring = true
    monitorable = false
    body_entered.connect(_on_body)


func _physics_process(delta: float) -> void:
    life -= delta
    if life <= 0.0:
        queue_free()
        return
    if not big and target != null and is_instance_valid(target) and not target.dead:
        var want: Vector3 = (target.global_position + Vector3.UP * 1.0 - global_position).normalized()
        dir = dir.lerp(want, clampf(delta * 1.5, 0.0, 1.0)).normalized()
    global_position += dir * speed * delta


func _on_body(b: Node) -> void:
    if _done or b == owner_f:
        return
    if b.has_method("take_damage"):
        if not visual_only:
            b.take_damage(dmg, dir, big, owner_f, false)
        _explode()
    elif b.has_meta("destructible"):
        if not visual_only:
            b.set_deferred("collision_layer", 0)
            var tw := b.create_tween()
            tw.tween_property(b, "scale", Vector3.ZERO, 0.3)
            tw.tween_callback(b.queue_free)
        _explode()
    elif b is StaticBody3D:
        _explode()


func _explode() -> void:
    _done = true
    var fx := MeshInstance3D.new()
    var sm := SphereMesh.new()
    sm.radius = 1.0
    sm.height = 2.0
    fx.mesh = sm
    var m := StandardMaterial3D.new()
    m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
    m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    m.albedo_color = Color(1, 0.8, 0.3, 0.7)
    fx.material_override = m
    var parent := get_parent()
    var pos := global_position
    var scl := 3.0 if big else 1.2
    parent.add_child(fx)
    fx.global_position = pos
    var tw := fx.create_tween()
    tw.tween_property(fx, "scale", Vector3.ONE * scl, 0.25).from(Vector3.ONE * 0.3)
    tw.parallel().tween_property(m, "albedo_color:a", 0.0, 0.25)
    tw.tween_callback(fx.queue_free)
    queue_free()
