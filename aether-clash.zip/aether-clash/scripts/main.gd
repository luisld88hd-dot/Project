extends Node
# Gestor de pantallas: recibe las señales de navegación y abre cada pantalla.

const BattleScript = preload("res://scripts/combat/battle.gd")
const FighterScript = preload("res://scripts/fighters/fighter.gd")

const SCREENS := {
    "story": "res://scripts/ui/story_menu.gd",
    "battle": "res://scripts/ui/battle_menu.gd",
    "training": "res://scripts/ui/battle_menu.gd",
    "survival": "res://scripts/ui/battle_menu.gd",
    "tournament": "res://scripts/ui/battle_menu.gd",
    "lan": "res://scripts/ui/lan_menu.gd",
    "custom": "res://scripts/ui/custom_editor.gd",
    "characters": "res://scripts/ui/character_select.gd",
    "settings": "res://scripts/ui/settings.gd"
}

var ui_layer: CanvasLayer
var current: Control = null
var bg3d: Node3D = null
var bg_cam: Camera3D = null
var battle: Node3D = null
var _angle := 0.0


func _ready() -> void:
    GameManager.apply_settings()
    ui_layer = CanvasLayer.new()
    add_child(ui_layer)
    go("main", {})


func _process(delta: float) -> void:
    if bg3d and bg_cam:
        _angle += delta * 0.25
        bg_cam.position = Vector3(sin(_angle) * 1.5, 2.2, 8.5)
        bg_cam.look_at(Vector3(0, 1.3, 0), Vector3.UP)


func _ensure_bg() -> void:
    if bg3d:
        return
    bg3d = Node3D.new()
    add_child(bg3d)
    var env := Environment.new()
    var sky := Sky.new()
    var sm := ProceduralSkyMaterial.new()
    sm.sky_top_color = Color("#06152E")
    sm.sky_horizon_color = Color("#3b6fc4")
    sm.ground_horizon_color = Color("#3b6fc4")
    sm.ground_bottom_color = Color("#081A3A")
    sky.sky_material = sm
    env.background_mode = Environment.BG_SKY
    env.sky = sky
    env.ambient_light_source = Environment.AMBIENT_SOURCE_SKY
    var we := WorldEnvironment.new()
    we.environment = env
    bg3d.add_child(we)
    var sun := DirectionalLight3D.new()
    sun.rotation_degrees = Vector3(-40, 25, 0)
    bg3d.add_child(sun)
    bg_cam = Camera3D.new()
    bg3d.add_child(bg_cam)
    bg_cam.current = true
    var ground := MeshInstance3D.new()
    var cm := CylinderMesh.new()
    cm.top_radius = 14.0
    cm.bottom_radius = 14.0
    cm.height = 0.4
    ground.mesh = cm
    var gm := StandardMaterial3D.new()
    gm.albedo_color = Color("#1c2f55")
    ground.material_override = gm
    ground.position.y = -0.2
    bg3d.add_child(ground)
    var lineup := [[0, -2.6, 0.0], [3, 0.0, -1.5], [8, 3.2, -0.5], [2, -5.2, -2.5], [9, 5.6, -2.5]]
    for l in lineup:
        var f = FighterScript.new()
        f.apply_character(GameManager.CHARACTERS[int(l[0])])
        f.puppet = true
        f.position = Vector3(float(l[1]), 0.0, float(l[2]))
        f.puppet_pos = f.position
        f.puppet_yaw = -float(l[1]) * 0.08
        f.rotation.y = f.puppet_yaw
        bg3d.add_child(f)
        if int(l[0]) == 3:
            f.charging = true


func _free_bg() -> void:
    if bg3d:
        bg3d.queue_free()
        bg3d = null
        bg_cam = null


func _clear_ui() -> void:
    if current:
        current.queue_free()
        current = null


func go(id: String, args: Dictionary) -> void:
    if id == "fight":
        _start_battle(args["cfg"])
        return
    _clear_ui()
    _ensure_bg()
    var scr: Control
    if id == "main":
        scr = load("res://scripts/ui/main_menu.gd").new()
        scr.navigation_requested.connect(func(sid: String): go(sid, {"mode": sid}))
    elif SCREENS.has(id):
        scr = load(SCREENS[id]).new()
        scr.set("args", {"mode": id})
        scr.navigate.connect(_on_nav)
    else:
        push_warning("Pantalla desconocida: " + id)
        go("main", {})
        return
    current = scr
    ui_layer.add_child(scr)


func _on_nav(sid: String, a: Dictionary) -> void:
    if a.is_empty():
        a = {"mode": sid}
    go(sid, a)


func _start_battle(cfg: Dictionary) -> void:
    _clear_ui()
    _free_bg()
    if battle:
        battle.queue_free()
    GameManager.battle_config = cfg
    battle = BattleScript.new()
    battle.finished.connect(_on_battle_finished.bind(cfg))
    add_child(battle)


func _on_battle_finished(action: String, cfg: Dictionary) -> void:
    if battle:
        battle.queue_free()
        battle = null
    match action:
        "retry":
            var c: Dictionary = cfg.duplicate()
            c["wave"] = 1
            _start_battle(c)
        "next":
            var n := GameManager.next_config(cfg)
            if n.is_empty():
                go("main", {})
            else:
                _start_battle(n)
        _:
            NetworkManager.close()
            go("main", {})
