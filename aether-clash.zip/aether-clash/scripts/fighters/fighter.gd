extends CharacterBody3D

signal died(fighter)
signal damaged(fighter, amount)
signal message(text)
signal blast_fired(origin, dir, big)
signal impact(strength)

const ProjectileScript = preload("res://scripts/combat/projectile.gd")

var display_name := "KAEL"
var max_hp := 1000.0
var hp := 1000.0
var max_energy := 100.0
var energy := 100.0
var ki_meter := 0.0
var speed := 9.0
var power := 1.0
var blast_mult := 1.0
var defense := 1.0
var can_fly := true
var body_scale := 1.0
var color := Color("#3a8dff")
var target = null
var team := 0
var puppet := false
var dead := false
var training := false
var marked := false
var ringout := false
var arena_radius := 55.0
var intent := {"move": Vector2.ZERO, "up": 0.0, "guard": false, "charge": false, "attack": false, "heavy": false, "blast": false, "dash": false, "ult": false, "spark": false}
var flying := false
var combo := 0
var combo_timer := 0.0
var atk_cd := 0.0
var blast_cd := 0.0
var dash_cd := 0.0
var stun := 0.0
var guard_age := 0.0
var guarding := false
var charging := false
var exhausted := false
# --- estilo Sparking Zero ---
var heavy_wind := 0.0        # carga del golpe fuerte (smash)
var launched := false        # enviado a volar (se puede rebotar / recuperar)
var bounced := false
var launch_age := 0.0
var hitstop := 0.0           # congelado breve al impactar
var chase_window := 0.0      # tiempo para perseguir con DASH tras lanzar al rival
var dash_time := 0.0         # Z-Burst en curso
var fly_boost := 0.0         # impulso acumulado al volar rapido (0..1)
var dash_dir := Vector3.ZERO
var dash_homing := false
var dash_hit := false
var spark_left := 0.0        # modo SPARKING activo
var spark_used := false
var puppet_pos := Vector3.ZERO
var puppet_yaw := 0.0
var _arm: Node3D
var _body: Node3D
var _aura: MeshInstance3D
var _shadow: MeshInstance3D
var _marker: Label3D
var _mats: Array = []
var _flash := 0.0
var _t := 0.0
var _ghost_t := 0.0


func apply_character(c: Dictionary, hp_mult: float = 1.0) -> void:
    display_name = str(c["name"])
    max_hp = 1000.0 * float(c["hp"]) * hp_mult
    hp = max_hp
    max_energy = float(c["energy"])
    energy = max_energy
    speed = 9.0 * float(c["speed"])
    power = float(c["power"])
    blast_mult = float(c["blast"])
    defense = float(c.get("defense", 1.0))
    can_fly = bool(c["fly"])
    body_scale = float(c["scale"])
    color = c["color"]


func _mat(col: Color, rough: float = 0.6, emit: float = 0.0) -> StandardMaterial3D:
    var m := StandardMaterial3D.new()
    m.albedo_color = col
    m.roughness = rough
    if emit > 0.0:
        m.emission_enabled = true
        m.emission = col
        m.emission_energy_multiplier = emit
    return m


func _mesh(m: Mesh, pos: Vector3, col: Color, parent: Node3D, rot: Vector3 = Vector3.ZERO, rough: float = 0.6, emit: float = 0.0) -> MeshInstance3D:
    var mi := MeshInstance3D.new()
    mi.mesh = m
    mi.material_override = _mat(col, rough, emit)
    mi.position = pos
    mi.rotation_degrees = rot
    parent.add_child(mi)
    _mats.append([mi.material_override, col])
    return mi


func _box(size: Vector3) -> BoxMesh:
    var b := BoxMesh.new()
    b.size = size
    return b


func _capsule(r: float, h: float) -> CapsuleMesh:
    var c := CapsuleMesh.new()
    c.radius = r
    c.height = maxf(h, r * 2.0)
    return c


func _sphere(r: float) -> SphereMesh:
    var sp := SphereMesh.new()
    sp.radius = r
    sp.height = r * 2.0
    return sp


func _cone(r: float, h: float) -> CylinderMesh:
    var c := CylinderMesh.new()
    c.top_radius = 0.0
    c.bottom_radius = r
    c.height = h
    return c


# Un miembro (brazo o pierna) con pivote en el hombro/cadera.
func _limb(parent: Node3D, pivot_pos: Vector3, length: float, radius: float, col: Color, end_col: Color) -> Node3D:
    var pivot := Node3D.new()
    pivot.position = pivot_pos
    parent.add_child(pivot)
    _mesh(_capsule(radius, length), Vector3(0, -length * 0.5, 0), col, pivot)
    _mesh(_sphere(radius * 1.15), Vector3(0, -length + radius * 0.4, 0), end_col, pivot)
    return pivot


func _build_model() -> void:
    var skin := Color("#e8b58a")
    var gi := color                      # traje principal (color del personaje)
    var gi_dark := color.darkened(0.45)
    var belt := Color("#f2f2f2") if color.get_luminance() < 0.6 else Color("#1b1b24")
    var boots := Color("#1b1b24")
    var hair_col := color.lightened(0.35)
    if display_name == "KAEL": hair_col = Color("#12121c")
    if display_name == "TITANOR": hair_col = Color("#3a3a46")
    var ap := _body   # todo cuelga de _body (escala por personaje)

    # Piernas (pantalón + botas)
    for side in [-1.0, 1.0]:
        var leg := _limb(ap, Vector3(0.17 * side, 0.92, 0), 0.9, 0.15, gi_dark, boots)
        leg.rotation_degrees.z = -2.0 * side
    # Cadera / cinturón
    _mesh(_box(Vector3(0.52, 0.2, 0.3)), Vector3(0, 0.98, 0), gi_dark, ap)
    _mesh(_box(Vector3(0.56, 0.08, 0.34)), Vector3(0, 1.1, 0), belt, ap)
    # Torso en forma de V (pecho ancho, cintura estrecha)
    _mesh(_capsule(0.3, 0.7), Vector3(0, 1.38, 0), gi, ap)
    _mesh(_box(Vector3(0.78, 0.34, 0.34)), Vector3(0, 1.62, 0), gi, ap)
    # Hombreras
    for side in [-1.0, 1.0]:
        _mesh(_sphere(0.2), Vector3(0.46 * side, 1.7, 0), gi_dark, ap)
    # Cuello y cabeza
    _mesh(_capsule(0.08, 0.2), Vector3(0, 1.86, 0), skin, ap)
    _mesh(_sphere(0.24), Vector3(0, 2.05, 0), skin, ap)
    # Ojos (brillo) para que se note hacia dónde mira (frente = -Z)
    for side in [-1.0, 1.0]:
        _mesh(_box(Vector3(0.09, 0.04, 0.03)), Vector3(0.095 * side, 2.08, -0.215), Color.WHITE, ap, Vector3.ZERO, 0.3, 1.2)
    # Pelo en picos (estilo anime)
    _mesh(_sphere(0.26), Vector3(0, 2.14, 0.03), hair_col, ap)
    var spikes := [
        [Vector3(0, 2.52, 0), Vector3(0, 0, 0), 0.13, 0.5],
        [Vector3(0.17, 2.42, 0.02), Vector3(0, 0, -35), 0.11, 0.42],
        [Vector3(-0.17, 2.42, 0.02), Vector3(0, 0, 35), 0.11, 0.42],
        [Vector3(0.0, 2.38, 0.2), Vector3(40, 0, 0), 0.11, 0.4],
        [Vector3(0.26, 2.22, 0.0), Vector3(0, 0, -70), 0.09, 0.34],
        [Vector3(-0.26, 2.22, 0.0), Vector3(0, 0, 70), 0.09, 0.34],
    ]
    for sp in spikes:
        _mesh(_cone(sp[2], sp[3]), sp[0], hair_col, ap, sp[1])
    # Brazos (el derecho es el que golpea)
    for side in [-1.0, 1.0]:
        var arm := _limb(ap, Vector3(0.5 * side, 1.72, 0), 0.78, 0.115, skin, skin)
        arm.rotation_degrees.z = -10.0 * side
        _mesh(_capsule(0.13, 0.3), Vector3(0, -0.1, 0), gi, arm)   # manga
        if side > 0.0:
            _arm = arm
    # Emblema en el pecho
    _mesh(_box(Vector3(0.16, 0.16, 0.02)), Vector3(0, 1.62, -0.18), Color("#FFD77B"), ap, Vector3(0, 0, 45), 0.3, 0.8)


func _ready() -> void:
    add_to_group("fighters")
    var cs := CollisionShape3D.new()
    var cap := CapsuleShape3D.new()
    cap.radius = 0.45 * body_scale
    cap.height = 2.2 * body_scale
    cs.shape = cap
    cs.position.y = 1.1 * body_scale
    add_child(cs)
    _body = Node3D.new()
    _body.scale = Vector3.ONE * body_scale
    add_child(_body)
    _build_model()
    # Sombra falsa bajo los pies (siempre visible, ayuda a ver la altura)
    var shadow := MeshInstance3D.new()
    var sc := CylinderMesh.new()
    sc.top_radius = 0.7
    sc.bottom_radius = 0.7
    sc.height = 0.02
    shadow.mesh = sc
    var sm_mat := StandardMaterial3D.new()
    sm_mat.albedo_color = Color(0, 0, 0, 0.35)
    sm_mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
    sm_mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    shadow.material_override = sm_mat
    shadow.position.y = 0.02
    add_child(shadow)
    _shadow = shadow
    _aura = MeshInstance3D.new()
    var sm := SphereMesh.new()
    sm.radius = 1.3
    sm.height = 2.9
    _aura.mesh = sm
    var am := StandardMaterial3D.new()
    am.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
    am.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    am.albedo_color = Color(1, 0.9, 0.4, 0.28)
    _aura.material_override = am
    _aura.position.y = 1.3
    _aura.visible = false
    _body.add_child(_aura)
    _marker = Label3D.new()
    _marker.text = "V"
    _marker.billboard = BaseMaterial3D.BILLBOARD_ENABLED
    _marker.no_depth_test = true
    _marker.pixel_size = 0.01
    _marker.font_size = 96
    _marker.modulate = Color("#ff4040")
    _marker.position = Vector3(0, 3.3 * body_scale, 0)
    _marker.visible = false
    add_child(_marker)


func _has_target() -> bool:
    return target != null and is_instance_valid(target) and not target.dead


func _pw() -> float:
    return power * (1.25 if spark_left > 0.0 else 1.0)


func _spd() -> float:
    return speed * (1.15 if spark_left > 0.0 else 1.0)


func _impulse(v: Vector3) -> void:
    velocity += v


func _clear_pulses() -> void:
    intent["attack"] = false
    intent["heavy"] = false
    intent["blast"] = false
    intent["ult"] = false
    intent["dash"] = false
    intent["spark"] = false


func _physics_process(delta: float) -> void:
    if dead:
        if not puppet:
            velocity.y -= 20.0 * delta
            move_and_slide()
        _update_visual(delta)
        return
    if hitstop > 0.0:
        hitstop -= delta
        _update_visual(delta)
        return
    combo_timer = maxf(0.0, combo_timer - delta)
    if combo_timer <= 0.0:
        combo = 0
    atk_cd = maxf(0.0, atk_cd - delta)
    blast_cd = maxf(0.0, blast_cd - delta)
    dash_cd = maxf(0.0, dash_cd - delta)
    stun = maxf(0.0, stun - delta)
    chase_window = maxf(0.0, chase_window - delta)
    spark_left = maxf(0.0, spark_left - delta)
    if puppet:
        var old := global_position
        var k := clampf(delta * 15.0, 0.0, 1.0)
        global_position = global_position.lerp(puppet_pos, k)
        rotation.y = lerp_angle(rotation.y, puppet_yaw, k)
        velocity = (global_position - old) / maxf(delta, 0.001)
    else:
        _simulate(delta)
    _update_visual(delta)


func _simulate(delta: float) -> void:
    for k in ["attack", "heavy", "blast", "dash", "ult", "spark", "guard", "charge"]:
        if not intent.has(k):
            intent[k] = false
    if not intent.has("move"):
        intent["move"] = Vector2.ZERO
    if not intent.has("up"):
        intent["up"] = 0.0
    var fwd := -global_transform.basis.z
    if _has_target() and not launched:
        var d: Vector3 = target.global_position - global_position
        d.y = 0.0
        if d.length() > 0.05:
            fwd = d.normalized()
            rotation.y = lerp_angle(rotation.y, atan2(-fwd.x, -fwd.z), clampf(delta * 12.0, 0.0, 1.0))
    var right := fwd.cross(Vector3.UP)
    if launched and stun <= 0.0:
        _end_launch()
    if stun > 0.0:
        _simulate_stun(delta)
        return

    guarding = bool(intent["guard"])
    if guarding:
        guard_age += delta
    else:
        guard_age = 0.0
    charging = bool(intent["charge"]) and not guarding
    if charging:
        energy += 30.0 * delta
        ki_meter += 3.0 * delta
    else:
        energy += (18.0 if spark_left > 0.0 else 5.0) * delta
    if training:
        energy = max_energy
    energy = clampf(energy, 0.0, max_energy)
    ki_meter = minf(ki_meter, 300.0)
    if energy <= 0.0:
        exhausted = true
    elif exhausted and energy >= 25.0:
        exhausted = false

    var mv: Vector2 = intent["move"]
    var up := float(intent["up"])
    var dir := right * mv.x + fwd * (-mv.y)

    # ---- acciones (estilo Sparking Zero) ----
    if intent["spark"]:
        _try_spark()
    if intent["dash"]:
        _try_dash(mv, fwd, right)
    if intent["attack"]:
        if guarding:
            _try_counter()
        else:
            _try_melee(fwd)
    if intent["heavy"]:
        _try_heavy()
    if intent["blast"]:
        _try_blast(fwd, false)
    if intent["ult"]:
        _try_blast(fwd, true)
    _clear_pulses()
    if heavy_wind > 0.0:
        heavy_wind -= delta
        if heavy_wind <= 0.0:
            _resolve_heavy()

    # ---- movimiento ----
    var spd := _spd()
    if charging:
        spd = 0.0
    elif guarding:
        spd *= 0.4
    elif heavy_wind > 0.0:
        spd *= 0.3
    if can_fly and exhausted:
        flying = false

    if dash_time > 0.0:
        _move_dash(delta)
    elif can_fly and not exhausted and (flying or (up > 0.1 and not charging)):
        _move_fly(delta, mv, up, fwd, right, spd)
    else:
        _move_ground(delta, dir * spd, up)
    if not (flying and can_fly):
        fly_boost = 0.0
    move_and_slide()
    _clamp_arena()


# Z-Burst en curso (sigue igual que antes, pero ahora conserva el impulso al terminar).
func _move_dash(delta: float) -> void:
    dash_time -= delta
    if dash_homing and _has_target():
        var to_t: Vector3 = target.global_position + Vector3.UP * 1.0 - global_position
        if to_t.length() > 0.1:
            dash_dir = to_t.normalized()
            if not can_fly:
                dash_dir.y = 0.0
                dash_dir = dash_dir.normalized()
        if dash_hit:
            var reach: float = 2.6 * body_scale + 0.5 * float(target.body_scale)
            if to_t.length() <= reach:
                _rush_hit(to_t)
    var dv := dash_dir * 34.0
    velocity.x = dv.x
    velocity.z = dv.z
    if can_fly:
        flying = true
        velocity.y = dv.y
    else:
        velocity.y = maxf(velocity.y - 25.0 * delta, -40.0)
    if dash_time <= 0.0 and can_fly:
        velocity *= 0.55   # no se frena en seco: sale del Z-Burst deslizando


# Suelo / caida. Los voladores que se quedan sin energia caen con peso real.
func _move_ground(delta: float, hv: Vector3, up: float) -> void:
    var on_ground := is_on_floor()
    var cur := Vector3(velocity.x, 0.0, velocity.z)
    var rate := 0.0
    if hv.length() > 0.1:
        rate = 48.0 if on_ground else 14.0
    else:
        rate = 60.0 if on_ground else 6.0
    cur = cur.move_toward(hv, rate * delta)
    velocity.x = cur.x
    velocity.z = cur.z
    if can_fly:
        velocity.y = maxf(velocity.y - 25.0 * delta, -40.0)
    elif on_ground and velocity.y <= 0.1:
        velocity.y = 9.0 if up > 0.5 else 0.0
    else:
        velocity.y = maxf(velocity.y - 25.0 * delta, -40.0)


# VUELO libre en 3D (estilo Sparking Zero):
#  - SUBIR despega con un impulso y se mantiene en el aire (hover suave), sin gravedad.
#  - El stick hacia adelante vuela HACIA el rival, incluida la altura (persecucion 3D).
#  - Aceleracion progresiva: mantener el vuelo acumula velocidad (fly_boost).
#  - Girar bruscamente derrapa: el momento no cambia de golpe, se curva.
#  - Al soltar el stick frena deslizando, no en seco.
func _move_fly(delta: float, mv: Vector2, up: float, fwd: Vector3, right: Vector3, spd: float) -> void:
    if not flying:
        flying = true
        if is_on_floor():
            velocity.y = maxf(velocity.y, 9.0)   # impulso de despegue
            impact.emit(0.08)
    # Direccion "adelante" en 3D: hacia el rival (se aplana cuando esta muy cerca).
    var f3 := Vector3(fwd.x, 0.0, fwd.z)
    if _has_target():
        var tt: Vector3 = (target.global_position + Vector3.UP * target.body_scale) - (global_position + Vector3.UP * body_scale)
        var dist := tt.length()
        if dist > 0.1:
            var k := clampf((dist - 3.0) / 5.0, 0.0, 1.0)
            f3 = (f3 * (1.0 - k) + tt.normalized() * k).normalized()
    var wish := right * mv.x + f3 * (-mv.y) + Vector3.UP * up * 0.9
    if wish.length() > 1.0:
        wish = wish.normalized()
    var moving := wish.length() > 0.08
    # Impulso acumulado por volar de forma sostenida.
    if mv.length() > 0.5 and not guarding and not charging:
        fly_boost = minf(1.0, fly_boost + delta * 0.8)
    else:
        fly_boost = maxf(0.0, fly_boost - delta * 2.2)
    var top := spd * 1.3 * (1.0 + 0.4 * fly_boost)
    var want := wish * top
    var accel := 0.0
    if moving:
        var al := 1.0
        if velocity.length() > 1.0:
            al = velocity.normalized().dot(wish.normalized())
        # alineado: acelera fuerte; contra el momento: derrapa y tarda en girar
        accel = lerpf(11.0, 30.0, (al + 1.0) * 0.5)
    else:
        accel = 10.0   # soltar = deslizar y frenar suave (hover)
    velocity = velocity.move_toward(want, accel * delta)
    # Energia: subir cuesta, volar rapido cuesta un poco, flotar es gratis.
    if up > 0.1:
        energy -= 3.0 * delta
    energy -= 1.2 * fly_boost * delta
    # Aterrizaje: tocar suelo sin querer subir.
    if is_on_floor() and up <= 0.1 and wish.y <= 0.05 and velocity.y <= 0.5:
        flying = false


# Estado de aturdimiento: fisica libre, con rebotes y recuperacion aerea.
func _simulate_stun(delta: float) -> void:
    guarding = false
    charging = false
    heavy_wind = 0.0
    dash_time = 0.0
    if launched:
        launch_age += delta
        if launch_age > 0.3 and (intent["dash"] or intent["guard"]) and energy >= 15.0 and not exhausted:
            energy -= 15.0
            stun = 0.0
            velocity *= 0.25
            _end_launch()
            message.emit("%s: RECUPERACION" % display_name)
            _clear_pulses()
            return
        velocity.y = maxf(velocity.y - 18.0 * delta, -45.0)
        velocity.x = move_toward(velocity.x, 0.0, 3.0 * delta)
        velocity.z = move_toward(velocity.z, 0.0, 3.0 * delta)
    else:
        velocity.x = move_toward(velocity.x, 0.0, 30.0 * delta)
        velocity.z = move_toward(velocity.z, 0.0, 30.0 * delta)
        if flying and can_fly:
            velocity.y = move_toward(velocity.y, 0.0, 20.0 * delta)
        else:
            velocity.y = maxf(velocity.y - 25.0 * delta, -40.0)
    _clear_pulses()
    var vb := velocity
    move_and_slide()
    if launched:
        _check_launch_collisions(vb)
    _clamp_arena()


func _end_launch() -> void:
    launched = false
    bounced = false
    launch_age = 0.0
    if can_fly and global_position.y > 1.0:
        flying = true


func _check_launch_collisions(vb: Vector3) -> void:
    for i in range(get_slide_collision_count()):
        var col := get_slide_collision(i)
        var n := col.get_normal()
        var into := -vb.dot(n)
        if into < 7.0:
            continue
        var other = col.get_collider()
        if other is CharacterBody3D:
            continue
        if other != null and other.has_meta("destructible"):
            other.set_deferred("collision_layer", 0)
            var tw: Tween = other.create_tween()
            tw.tween_property(other, "scale", Vector3.ZERO, 0.3)
            tw.tween_callback(other.queue_free)
            velocity = vb * 0.7
            _slam_damage(into * 0.6)
        elif n.y > 0.7:
            if not bounced:
                bounced = true
                velocity = Vector3(vb.x * 0.6, into * 0.45, vb.z * 0.6)
                _slam_damage(into)
        else:
            velocity = vb.bounce(n) * 0.5
            _slam_damage(into)
        break


func _slam_damage(into: float) -> void:
    var d := clampf(into * 1.5, 8.0, 60.0)
    hp -= d
    _flash = 0.12
    hitstop = maxf(hitstop, 0.06)
    damaged.emit(self, d)
    impact.emit(clampf(into / 25.0, 0.3, 1.0))
    if hp <= 0.0:
        _die()


func _clamp_arena() -> void:
    var p := global_position
    if ringout:
        if p.y < -15.0:
            _die()
    else:
        var flat := Vector2(p.x, p.z)
        if flat.length() > arena_radius:
            var nrm := flat.normalized()
            flat = nrm * arena_radius
            global_position = Vector3(flat.x, p.y, flat.y)
            var vn := velocity.x * nrm.x + velocity.z * nrm.y
            if launched and vn > 6.0:
                velocity.x -= 1.5 * vn * nrm.x
                velocity.z -= 1.5 * vn * nrm.y
                _slam_damage(vn)
            elif vn > 0.0:
                velocity.x -= vn * nrm.x
                velocity.z -= vn * nrm.y
    if global_position.y > 45.0:
        global_position.y = 45.0
        velocity.y = minf(velocity.y, 0.0)


# ---------------------------------------------------------------- acciones
func _reach_to_target(heavy: bool) -> float:
    return (3.4 if heavy else 3.0) * body_scale + 0.55 * float(target.body_scale)


# GOLPE: combo ligero de 5 golpes con "iman" hacia el rival; el 5.o lanza.
func _try_melee(fwd: Vector3) -> void:
    if atk_cd > 0.0 or guarding or charging or heavy_wind > 0.0:
        return
    combo = combo + 1 if combo_timer > 0.0 else 1
    if combo > 5:
        combo = 1
    combo_timer = 0.8
    var finisher := combo == 5
    atk_cd = 0.5 if finisher else 0.22
    _swing()
    if _has_target():
        var d: Vector3 = target.global_position - global_position
        var flat := Vector3(d.x, 0.0, d.z)
        if d.length() > 2.0 and d.length() <= 8.0 and flat.length() > 0.05:
            _impulse(flat.normalized() * 10.0 + Vector3.UP * clampf(d.y, -1.0, 1.0) * (4.0 if flying else 0.0))
        if d.length() <= _reach_to_target(false) + 0.6:
            var dmg := (24.0 + 6.0 * combo) * _pw() * (1.8 if finisher else 1.0)
            target.take_damage(dmg, d.normalized(), finisher, self, false, "light")
            ki_meter += 6.0
            if finisher:
                chase_window = 1.0


# FUERTE: golpe de carga corta que lanza al rival y rompe guardias (smash).
func _try_heavy() -> void:
    if atk_cd > 0.0 or guarding or charging or heavy_wind > 0.0 or exhausted or energy < 10.0:
        return
    energy -= 10.0
    heavy_wind = 0.2
    atk_cd = 0.95
    combo = 0
    combo_timer = 0.0
    if _arm != null:
        var tw := create_tween()
        tw.tween_property(_arm, "rotation:x", -2.4, 0.18)
        tw.tween_property(_arm, "rotation:x", 2.2, 0.07)
        tw.tween_property(_arm, "rotation:x", 0.0, 0.25)


func _resolve_heavy() -> void:
    if not _has_target():
        return
    var d: Vector3 = target.global_position - global_position
    var flat := Vector3(d.x, 0.0, d.z)
    if flat.length() > 0.05:
        _impulse(flat.normalized() * 12.0)
    if d.length() <= _reach_to_target(true) + 0.6:
        var dir := d.normalized()
        if flying and d.y < -1.2:
            dir = (dir * 0.4 + Vector3.DOWN).normalized()   # smash hacia abajo
        target.take_damage(95.0 * _pw(), dir, true, self, false, "heavy")
        chase_window = 1.0
        ki_meter += 10.0


# GUARDIA + GOLPE: contraataque (cuesta media barra de ki). No se puede bloquear.
func _try_counter() -> void:
    if atk_cd > 0.0 or ki_meter < 50.0 or not _has_target():
        return
    ki_meter -= 50.0
    atk_cd = 0.7
    _swing()
    var d: Vector3 = target.global_position - global_position
    if d.length() <= _reach_to_target(false) + 1.5:
        target.take_damage(65.0 * _pw(), d.normalized(), true, self, true, "counter")
        chase_window = 1.0
        message.emit("%s: CONTRAGOLPE" % display_name)


# SPARKING: una vez por combate (1 barra de ki). Mas dano, velocidad y energia.
func _try_spark() -> void:
    if spark_used or spark_left > 0.0 or ki_meter < 100.0:
        return
    spark_used = true
    ki_meter -= 100.0
    spark_left = 18.0
    energy = max_energy
    exhausted = false
    message.emit("¡SPARKING!")
    impact.emit(0.5)


# DASH: sin guardia = Z-Burst (hacia el stick o buscando al rival);
# con guardia = desplazamiento tras el rival; tras lanzarlo = persecucion.
func _try_dash(mv: Vector2, fwd: Vector3, right: Vector3) -> void:
    if dash_cd > 0.0 or exhausted:
        return
    if guarding and _has_target():
        if energy < 25.0:
            return
        energy -= 25.0
        dash_cd = 1.2
        var tf: Vector3 = -target.global_transform.basis.z
        global_position = target.global_position - tf * 2.4
        velocity = Vector3.ZERO
        atk_cd = 0.15
        message.emit("%s: DESPLAZAMIENTO" % display_name)
        impact.emit(0.15)
        return
    if chase_window > 0.0 and _has_target():
        if energy < 15.0:
            return
        energy -= 15.0
        dash_cd = 0.4
        var to_t: Vector3 = target.global_position - global_position
        var flat := Vector3(to_t.x, 0.0, to_t.z)
        var back := flat.normalized() if flat.length() > 0.05 else fwd
        global_position = Vector3(target.global_position.x, target.global_position.y, target.global_position.z) - back * 2.2
        velocity = Vector3.ZERO
        atk_cd = 0.0
        combo_timer = 0.8
        chase_window = 0.0
        message.emit("PERSECUCION")
        impact.emit(0.2)
        return
    if energy < 12.0:
        return
    energy -= 12.0
    dash_cd = 0.55
    dash_time = 0.22
    dash_hit = false
    dash_homing = false
    if mv.length() > 0.3:
        dash_dir = (right * mv.x + fwd * (-mv.y)).normalized()
    elif _has_target():
        var to_t2: Vector3 = target.global_position + Vector3.UP * 1.0 - global_position
        dash_dir = to_t2.normalized()
        dash_homing = true
        dash_hit = true
    else:
        dash_dir = fwd
    if not can_fly:
        dash_dir.y = 0.0
        dash_dir = dash_dir.normalized()
    impact.emit(0.05)


# El Z-Burst dirigido al rival termina en un golpe de embestida.
func _rush_hit(to_t: Vector3) -> void:
    dash_hit = false
    dash_time = 0.0
    dash_dir = Vector3.ZERO
    combo = 1
    combo_timer = 0.8
    atk_cd = 0.1
    target.take_damage(40.0 * _pw(), to_t.normalized(), false, self, false, "rush")
    ki_meter += 4.0
    _swing()


func _swing() -> void:
    if _arm == null:
        return
    var tw := create_tween()
    tw.tween_property(_arm, "rotation:x", 1.7, 0.07)
    tw.tween_property(_arm, "rotation:x", 0.0, 0.14)


func _try_blast(fwd: Vector3, big: bool) -> void:
    if big:
        if ki_meter < 200.0:
            return
        ki_meter -= 200.0
    else:
        if blast_cd > 0.0 or energy < 12.0 or exhausted:
            return
        energy -= 12.0
        blast_cd = 0.35
    var origin := global_position + Vector3.UP * 1.4 * body_scale + fwd * 1.0
    var aim := fwd
    if _has_target():
        aim = (target.global_position + Vector3.UP * 1.0 - origin).normalized()
    var dmg := (380.0 if big else 70.0) * blast_mult * (1.2 if spark_left > 0.0 else 1.0)
    spawn_projectile(origin, aim, dmg, big, false)
    blast_fired.emit(origin, aim, big)
    if big:
        impact.emit(0.4)


func spawn_projectile(origin: Vector3, dir: Vector3, dmg: float, big: bool, visual_only: bool) -> void:
    var p = ProjectileScript.new()
    p.setup(self, target, dir, dmg, big, visual_only)
    p.position = origin
    get_parent().add_child(p)


func take_damage(dmg: float, dir: Vector3, launch: bool, attacker, unblockable: bool, kind: String = "light") -> void:
    if dead:
        return
    var flat := Vector3(dir.x, 0.0, dir.z).normalized()
    var amt := dmg * defense * (0.85 if spark_left > 0.0 else 1.0)
    var hs := 0.05
    if guarding and not unblockable:
        if guard_age < 0.2:
            message.emit("CONTRAATAQUE PERFECTO")
            if attacker != null and is_instance_valid(attacker):
                attacker.stun = maxf(attacker.stun, 0.7)
                attacker._impulse(flat * 8.0)
                attacker.hitstop = maxf(attacker.hitstop, 0.08)
            ki_meter += 15.0
            hitstop = maxf(hitstop, 0.08)
            impact.emit(0.3)
            return
        amt *= 0.2
        energy -= dmg * (0.6 if kind == "heavy" else 0.25)
        _impulse(flat * 3.0)
        if energy <= 0.0:
            energy = 0.0
            stun = 1.0
            guarding = false
            message.emit("GUARDIA ROTA")
    else:
        if launch:
            stun = 0.9
            launched = true
            bounced = false
            launch_age = 0.0
            if can_fly:
                flying = true
            if kind == "heavy" and dir.y < -0.5:
                velocity = Vector3.DOWN * 28.0 + flat * 6.0
            else:
                velocity = flat * (22.0 if kind == "heavy" else 17.0) + Vector3.UP * (7.0 if kind == "heavy" else 9.0)
            hs = 0.12
        else:
            stun = 0.4 if kind == "rush" else 0.28
            _impulse(flat * 4.0)
    hp -= amt
    ki_meter += amt * 0.1
    if attacker != null and is_instance_valid(attacker):
        attacker.ki_meter += amt * 0.08
        attacker.hitstop = maxf(attacker.hitstop, hs)
    hitstop = maxf(hitstop, hs)
    _flash = 0.12
    damaged.emit(self, amt)
    impact.emit(0.6 if launch else 0.15)
    if hp <= 0.0:
        _die()


func _die() -> void:
    if dead:
        return
    dead = true
    hp = 0.0
    flying = false
    launched = false
    var tw := create_tween()
    tw.tween_property(_body, "rotation:x", -1.5, 0.4)
    died.emit(self)


func _afterimage() -> void:
    if get_parent() == null:
        return
    var mi := MeshInstance3D.new()
    var cm := CapsuleMesh.new()
    cm.radius = 0.4 * body_scale
    cm.height = 2.2 * body_scale
    mi.mesh = cm
    var m := StandardMaterial3D.new()
    m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
    m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    m.albedo_color = Color(color.r, color.g, color.b, 0.45)
    mi.material_override = m
    get_parent().add_child(mi)
    mi.global_position = global_position + Vector3.UP * 1.1 * body_scale
    var tw := mi.create_tween()
    tw.tween_property(m, "albedo_color:a", 0.0, 0.25)
    tw.tween_callback(mi.queue_free)


func _update_visual(delta: float) -> void:
    _t += delta
    _flash = maxf(0.0, _flash - delta)
    for m in _mats:
        m[0].albedo_color = Color.WHITE if _flash > 0.0 else m[1]
    var show_aura := (charging or guarding or spark_left > 0.0) and not dead
    _aura.visible = show_aura
    if show_aura:
        var am := _aura.material_override as StandardMaterial3D
        var sc := 1.0
        if guarding:
            am.albedo_color = Color(0.4, 0.7, 1.0, 0.28)
        elif charging:
            am.albedo_color = Color(1.0, 0.85, 0.3, 0.3)
        else:
            am.albedo_color = Color(1.0, 0.35, 0.12, 0.34)
            sc = 1.25
        _aura.scale = Vector3.ONE * sc * (1.0 + 0.08 * sin(_t * 18.0))
    if not dead:
        # Inclinacion segun la velocidad 3D: se tumba al volar rapido, sube/baja con la trayectoria
        var lv := global_transform.basis.inverse() * velocity
        var fs := -lv.z
        var tx := 0.0
        if launched:
            tx = 0.9
        elif (flying and can_fly) or dash_time > 0.0:
            tx = -clampf(fs * 0.05, -0.35, 1.2) + clampf(lv.y * 0.035, -0.55, 0.45)
            tx = clampf(tx, -1.4, 0.5)
        else:
            tx = -clampf(fs * 0.012, -0.15, 0.25)
        var tz := -clampf(lv.x * 0.04, -0.6, 0.6) if (flying or dash_time > 0.0) else -clampf(lv.x * 0.02, -0.3, 0.3)
        var k := clampf(delta * 8.0, 0.0, 1.0)
        _body.rotation.x = lerpf(_body.rotation.x, tx, k)
        _body.rotation.z = lerpf(_body.rotation.z, tz, k)
        _body.position.y = sin(_t * 2.4) * 0.07 if (flying and not launched and velocity.length() < 3.0) else lerpf(_body.position.y, 0.0, k)
        if dash_time > 0.0 or (flying and fly_boost > 0.85):
            _ghost_t -= delta
            if _ghost_t <= 0.0:
                _ghost_t = 0.03 if dash_time > 0.0 else 0.07
                _afterimage()
    if _shadow != null:
        _shadow.global_position = Vector3(global_position.x, 0.03, global_position.z)
        var h: float = clampf(global_position.y, 0.0, 20.0)
        _shadow.scale = Vector3.ONE * (1.0 - h * 0.03) * body_scale
        _shadow.visible = not dead and global_position.y > -0.5
    _marker.visible = marked and not dead


func get_state() -> Array:
    return [global_position, rotation.y, hp, energy, flying, guarding, charging, ki_meter, combo, spark_left, launched, dash_time > 0.0]


func apply_state(s: Array) -> void:
    puppet_pos = s[0]
    puppet_yaw = float(s[1])
    if float(s[2]) < hp:
        _flash = 0.12
    hp = float(s[2])
    energy = float(s[3])
    flying = bool(s[4])
    guarding = bool(s[5])
    charging = bool(s[6])
    ki_meter = float(s[7])
    combo = int(s[8])
    spark_left = float(s[9])
    if spark_left > 0.0:
        spark_used = true
    launched = bool(s[10])
    dash_time = 0.05 if bool(s[11]) else 0.0
    if hp <= 0.0 and not dead:
        _die()
