extends CharacterBody3D

signal died(fighter)
signal damaged(fighter, amount)
signal message(text)
signal blast_fired(origin, dir, big)

const ProjectileScript = preload("res://scripts/combat/projectile.gd")

var display_name := "KAEL"
var max_hp := 1000.0
var hp := 1000.0
var max_energy := 100.0
var energy := 100.0
var ki_meter := 0.0
var speed := 9.0
var power := 1.0
var blast_mult := 1.0
var defense := 1.0
var can_fly := true
var body_scale := 1.0
var color := Color("#3a8dff")
var target = null
var team := 0
var puppet := false
var dead := false
var training := false
var marked := false
var ringout := false
var arena_radius := 55.0
var intent := {"move": Vector2.ZERO, "up": 0.0, "guard": false, "charge": false, "attack": false, "blast": false, "dash": false, "ult": false}
var flying := false
var combo := 0
var combo_timer := 0.0
var atk_cd := 0.0
var blast_cd := 0.0
var dash_cd := 0.0
var stun := 0.0
var kb := Vector3.ZERO
var lunge := 0.0
var guard_age := 0.0
var guarding := false
var charging := false
var exhausted := false
var puppet_pos := Vector3.ZERO
var puppet_yaw := 0.0
var _arm: Node3D
var _body: Node3D
var _aura: MeshInstance3D
var _marker: Label3D
var _mats: Array = []
var _flash := 0.0
var _t := 0.0


func apply_character(c: Dictionary, hp_mult: float = 1.0) -> void:
    display_name = str(c["name"])
    max_hp = 1000.0 * float(c["hp"]) * hp_mult
    hp = max_hp
    max_energy = float(c["energy"])
    energy = max_energy
    speed = 9.0 * float(c["speed"])
    power = float(c["power"])
    blast_mult = float(c["blast"])
    defense = float(c.get("defense", 1.0))
    can_fly = bool(c["fly"])
    body_scale = float(c["scale"])
    color = c["color"]


func _mesh(m: Mesh, pos: Vector3, col: Color, parent: Node3D) -> MeshInstance3D:
    var mi := MeshInstance3D.new()
    mi.mesh = m
    var mat := StandardMaterial3D.new()
    mat.albedo_color = col
    mi.material_override = mat
    mi.position = pos
    parent.add_child(mi)
    _mats.append([mat, col])
    return mi


func _ready() -> void:
    add_to_group("fighters")
    var cs := CollisionShape3D.new()
    var cap := CapsuleShape3D.new()
    cap.radius = 0.45 * body_scale
    cap.height = 1.9 * body_scale
    cs.shape = cap
    cs.position.y = 0.95 * body_scale
    add_child(cs)
    _body = Node3D.new()
    _body.scale = Vector3.ONE * body_scale
    add_child(_body)
    var dark := color.darkened(0.55)
    var skin := Color("#e8b58a")
    var torso := CapsuleMesh.new()
    torso.radius = 0.34
    torso.height = 1.0
    _mesh(torso, Vector3(0, 1.15, 0), color, _body)
    var legs := BoxMesh.new()
    legs.size = Vector3(0.5, 0.8, 0.3)
    _mesh(legs, Vector3(0, 0.4, 0), dark, _body)
    var head := SphereMesh.new()
    head.radius = 0.22
    head.height = 0.44
    _mesh(head, Vector3(0, 1.85, 0), skin, _body)
    var hair := CylinderMesh.new()
    hair.top_radius = 0.0
    hair.bottom_radius = 0.26
    hair.height = 0.55
    _mesh(hair, Vector3(0, 2.12, 0), color.lightened(0.3), _body)
    var arm_mesh := BoxMesh.new()
    arm_mesh.size = Vector3(0.18, 0.7, 0.18)
    for side in [-1.0, 1.0]:
        var pivot := Node3D.new()
        pivot.position = Vector3(0.5 * side, 1.5, 0)
        _body.add_child(pivot)
        _mesh(arm_mesh, Vector3(0, -0.3, 0), skin, pivot)
        if side > 0.0:
            _arm = pivot
    _aura = MeshInstance3D.new()
    var sm := SphereMesh.new()
    sm.radius = 1.2
    sm.height = 2.4
    _aura.mesh = sm
    var am := StandardMaterial3D.new()
    am.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
    am.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    am.albedo_color = Color(1, 0.9, 0.4, 0.28)
    _aura.material_override = am
    _aura.position.y = 1.1
    _aura.visible = false
    _body.add_child(_aura)
    _marker = Label3D.new()
    _marker.text = "V"
    _marker.billboard = BaseMaterial3D.BILLBOARD_ENABLED
    _marker.no_depth_test = true
    _marker.pixel_size = 0.01
    _marker.font_size = 96
    _marker.modulate = Color("#ff4040")
    _marker.position = Vector3(0, 2.9 * body_scale, 0)
    _marker.visible = false
    add_child(_marker)


func _has_target() -> bool:
    return target != null and is_instance_valid(target) and not target.dead


func _physics_process(delta: float) -> void:
    if dead:
        if not puppet:
            velocity.y -= 20.0 * delta
            move_and_slide()
        _update_visual(delta)
        return
    combo_timer = maxf(0.0, combo_timer - delta)
    if combo_timer <= 0.0:
        combo = 0
    atk_cd = maxf(0.0, atk_cd - delta)
    blast_cd = maxf(0.0, blast_cd - delta)
    dash_cd = maxf(0.0, dash_cd - delta)
    stun = maxf(0.0, stun - delta)
    if puppet:
        var k := clampf(delta * 15.0, 0.0, 1.0)
        global_position = global_position.lerp(puppet_pos, k)
        rotation.y = lerp_angle(rotation.y, puppet_yaw, k)
    else:
        _simulate(delta)
    _update_visual(delta)


func _simulate(delta: float) -> void:
    var fwd := -global_transform.basis.z
    if _has_target():
        var d: Vector3 = target.global_position - global_position
        d.y = 0.0
        if d.length() > 0.05:
            fwd = d.normalized()
            rotation.y = lerp_angle(rotation.y, atan2(-fwd.x, -fwd.z), clampf(delta * 12.0, 0.0, 1.0))
    var right := fwd.cross(Vector3.UP)
    var stunned := stun > 0.0
    guarding = bool(intent["guard"]) and not stunned
    if guarding:
        guard_age += delta
    else:
        guard_age = 0.0
    charging = bool(intent["charge"]) and not stunned and not guarding
    if charging:
        energy += 30.0 * delta
        ki_meter += 3.0 * delta
    else:
        energy += 5.0 * delta
    if training:
        energy = max_energy
    energy = clampf(energy, 0.0, max_energy)
    ki_meter = minf(ki_meter, 300.0)
    if energy <= 0.0:
        exhausted = true
    elif exhausted and energy >= 25.0:
        exhausted = false
    if not stunned:
        if intent["attack"]:
            _try_melee(fwd)
        if intent["blast"]:
            _try_blast(fwd, false)
        if intent["ult"]:
            _try_blast(fwd, true)
        if intent["dash"]:
            _try_dash()
    intent["attack"] = false
    intent["blast"] = false
    intent["ult"] = false
    intent["dash"] = false

    var mv: Vector2 = intent["move"]
    var up := float(intent["up"])
    if stunned:
        mv = Vector2.ZERO
        up = 0.0
    var dir := right * mv.x + fwd * (-mv.y)
    var spd := speed * (1.25 if flying else 1.0)
    if charging:
        spd = 0.0
    elif guarding:
        spd *= 0.4
    var hv := dir * spd
    if lunge > 0.0:
        lunge -= delta
        hv += fwd * 12.0
    hv += Vector3(kb.x, 0.0, kb.z)
    kb = kb.move_toward(Vector3.ZERO, 25.0 * delta)

    if can_fly:
        if exhausted:
            flying = false
        if up > 0.1 and not exhausted and not charging:
            flying = true
            energy -= 3.0 * delta
        if flying:
            var vy := up * (7.0 if up > 0.0 else 9.0)
            if charging:
                vy = 0.0
            velocity.y = lerpf(velocity.y, vy, clampf(delta * 8.0, 0.0, 1.0))
            if is_on_floor() and up <= 0.1 and velocity.y <= 0.5:
                flying = false
        else:
            velocity.y -= 25.0 * delta
    else:
        if is_on_floor() and velocity.y <= 0.1:
            velocity.y = 9.0 if up > 0.5 else 0.0
        else:
            velocity.y -= 25.0 * delta
    velocity.x = hv.x
    velocity.z = hv.z
    move_and_slide()

    var p := global_position
    if ringout:
        if p.y < -15.0:
            _die()
    else:
        var flat := Vector2(p.x, p.z)
        if flat.length() > arena_radius:
            flat = flat.normalized() * arena_radius
            global_position = Vector3(flat.x, p.y, flat.y)
    if global_position.y > 45.0:
        global_position.y = 45.0


func _try_melee(fwd: Vector3) -> void:
    if atk_cd > 0.0 or guarding or charging:
        return
    combo = combo + 1 if combo_timer > 0.0 else 1
    if combo > 4:
        combo = 1
    combo_timer = 0.8
    var finisher := combo == 4
    atk_cd = 0.55 if finisher else 0.26
    lunge = 0.12
    _swing()
    if _has_target():
        var d: Vector3 = target.global_position - global_position
        var reach := 3.0 * body_scale + 0.5 * target.body_scale
        if d.length() <= reach:
            var dmg := (30.0 + 8.0 * combo) * power * (1.8 if finisher else 1.0)
            target.take_damage(dmg, d.normalized(), finisher, self, false)
            ki_meter += 6.0


func _swing() -> void:
    if _arm == null:
        return
    var tw := create_tween()
    tw.tween_property(_arm, "rotation:x", 1.7, 0.07)
    tw.tween_property(_arm, "rotation:x", 0.0, 0.14)


func _try_blast(fwd: Vector3, big: bool) -> void:
    if big:
        if ki_meter < 200.0:
            return
        ki_meter -= 200.0
    else:
        if blast_cd > 0.0 or energy < 12.0 or exhausted:
            return
        energy -= 12.0
        blast_cd = 0.35
    var origin := global_position + Vector3.UP * 1.4 * body_scale + fwd * 1.0
    var aim := fwd
    if _has_target():
        aim = (target.global_position + Vector3.UP * 1.0 - origin).normalized()
    var dmg := (380.0 if big else 70.0) * blast_mult
    spawn_projectile(origin, aim, dmg, big, false)
    blast_fired.emit(origin, aim, big)


func spawn_projectile(origin: Vector3, dir: Vector3, dmg: float, big: bool, visual_only: bool) -> void:
    var p = ProjectileScript.new()
    p.setup(self, target, dir, dmg, big, visual_only)
    p.position = origin
    get_parent().add_child(p)


func _try_dash() -> void:
    if dash_cd > 0.0 or energy < 20.0 or exhausted or not _has_target():
        return
    var d: Vector3 = target.global_position - global_position
    if d.length() > 30.0:
        return
    energy -= 20.0
    dash_cd = 1.6
    var tf: Vector3 = -target.global_transform.basis.z
    global_position = target.global_position - tf * 2.4
    velocity = Vector3.ZERO
    atk_cd = 0.3
    message.emit("%s: DESPLAZAMIENTO" % display_name)


func take_damage(dmg: float, dir: Vector3, launch: bool, attacker, unblockable: bool) -> void:
    if dead:
        return
    var flat := Vector3(dir.x, 0.0, dir.z).normalized()
    var amt := dmg * defense
    if guarding and not unblockable:
        if guard_age < 0.2:
            message.emit("CONTRAATAQUE PERFECTO")
            if attacker != null and is_instance_valid(attacker):
                attacker.stun = maxf(attacker.stun, 0.7)
                attacker.kb = flat * 8.0
            ki_meter += 15.0
            return
        amt *= 0.2
        energy -= dmg * 0.25
        kb = flat * 3.0
        if energy <= 0.0:
            energy = 0.0
            stun = 1.0
            guarding = false
            message.emit("GUARDIA ROTA")
    else:
        stun = 0.7 if launch else 0.28
        kb = flat * (15.0 if launch else 4.0)
        if launch:
            velocity.y = 8.0
            if can_fly:
                flying = true
    hp -= amt
    ki_meter += amt * 0.1
    if attacker != null and is_instance_valid(attacker):
        attacker.ki_meter += amt * 0.08
    _flash = 0.12
    damaged.emit(self, amt)
    if hp <= 0.0:
        _die()


func _die() -> void:
    if dead:
        return
    dead = true
    hp = 0.0
    flying = false
    var tw := create_tween()
    tw.tween_property(_body, "rotation:x", -1.5, 0.4)
    died.emit(self)


func _update_visual(delta: float) -> void:
    _t += delta
    _flash = maxf(0.0, _flash - delta)
    for m in _mats:
        m[0].albedo_color = Color.WHITE if _flash > 0.0 else m[1]
    var show_aura := (charging or guarding) and not dead
    _aura.visible = show_aura
    if show_aura:
        var am := _aura.material_override as StandardMaterial3D
        am.albedo_color = Color(0.4, 0.7, 1.0, 0.28) if guarding else Color(1.0, 0.85, 0.3, 0.3)
        _aura.scale = Vector3.ONE * (1.0 + 0.08 * sin(_t * 18.0))
    if not dead:
        _body.position.y = sin(_t * 3.0) * 0.06 if flying else 0.0
    _marker.visible = marked and not dead


func get_state() -> Array:
    return [global_position, rotation.y, hp, energy, flying, guarding, charging, ki_meter, combo]


func apply_state(s: Array) -> void:
    puppet_pos = s[0]
    puppet_yaw = float(s[1])
    if float(s[2]) < hp:
        _flash = 0.12
    hp = float(s[2])
    energy = float(s[3])
    flying = bool(s[4])
    guarding = bool(s[5])
    charging = bool(s[6])
    ki_meter = float(s[7])
    combo = int(s[8])
    if hp <= 0.0 and not dead:
        _die()
