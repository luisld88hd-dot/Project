extends Node
# Multijugador LAN: ENet (UDP) con el anfitrión como autoridad + descubrimiento por broadcast UDP.

signal lobby_updated
signal rooms_updated
signal match_started
signal snapshot_received(data)
signal input_received(data)
signal fx_received(kind, data)
signal disconnected(reason)
signal status_changed(text)

const GAME_PORT := 24565
const DISCOVERY_PORT := 24566

var online := false
var is_host := false
var in_match := false
var player_name := "Jugador"
var room_name := "Sala de Aether"
var guest_id := 0
var lobby := {"host_name": "", "guest_name": "", "host_char": 0, "guest_char": 1, "arena": 0, "guest_connected": false, "guest_ready": false}
var rooms := {}

var _bcast: PacketPeerUDP
var _listen: PacketPeerUDP
var _bc_timer := 0.0
var _signals_ready := false
var _broadcast_targets: Array[String] = ["255.255.255.255"]


func _ready() -> void:
    set_process(true)


func _wire() -> void:
    if _signals_ready:
        return
    _signals_ready = true
    multiplayer.peer_connected.connect(_on_peer_connected)
    multiplayer.peer_disconnected.connect(_on_peer_disconnected)
    multiplayer.connected_to_server.connect(_on_connected)
    multiplayer.connection_failed.connect(_on_failed)
    multiplayer.server_disconnected.connect(_on_server_gone)


func local_ips() -> Array:
    var out: Array = []
    var rx := RegEx.new()
    rx.compile("^\\d+\\.\\d+\\.\\d+\\.\\d+$")
    for a in IP.get_local_addresses():
        if rx.search(a) and not a.begins_with("127.") and not a.begins_with("169.254."):
            out.append(a)
    return out


func close() -> void:
    stop_search()
    if _bcast:
        _bcast.close()
        _bcast = null
    if multiplayer.multiplayer_peer != null:
        multiplayer.multiplayer_peer.close()
        multiplayer.multiplayer_peer = null
    online = false
    is_host = false
    in_match = false
    guest_id = 0


func host_create() -> bool:
    close()
    _wire()
    var peer := ENetMultiplayerPeer.new()
    var err := peer.create_server(GAME_PORT, 1)
    if err != OK:
        status_changed.emit("No se pudo crear la sala (error %d). ¿Ya hay una sala abierta?" % err)
        return false
    multiplayer.multiplayer_peer = peer
    online = true
    is_host = true
    lobby = {"host_name": player_name, "guest_name": "", "host_char": GameManager.selected_char, "guest_char": 1, "arena": 0, "guest_connected": false, "guest_ready": false}
    _bcast = PacketPeerUDP.new()
    _bcast.set_broadcast_enabled(true)
    _broadcast_targets = ["255.255.255.255"]
    # Algunos routers filtran el broadcast global; añadimos broadcast dirigido /24.
    for addr in local_ips():
        var octets := addr.split(".")
        if octets.size() == 4:
            _broadcast_targets.append("%s.%s.%s.255" % [octets[0], octets[1], octets[2]])
    status_changed.emit("Sala LAN creada (sin internet). Esperando al otro teléfono...")
    return true


func join(ip: String, port: int = GAME_PORT) -> bool:
    close()
    _wire()
    var peer := ENetMultiplayerPeer.new()
    var err := peer.create_client(ip, port)
    if err != OK:
        status_changed.emit("No se pudo iniciar la conexión (error %d)." % err)
        return false
    multiplayer.multiplayer_peer = peer
    online = true
    is_host = false
    status_changed.emit("Conectando por Wi-Fi local a %s:%d (no requiere internet)..." % [ip, port])
    return true


func start_search() -> void:
    stop_search()
    rooms.clear()
    _listen = PacketPeerUDP.new()
    var err := _listen.bind(DISCOVERY_PORT)
    if err != OK:
        _listen = null
        status_changed.emit("No se pudo escuchar el descubrimiento (error %d). Usa IP manual." % err)


func stop_search() -> void:
    if _listen:
        _listen.close()
        _listen = null


func _process(delta: float) -> void:
    if is_host and online and _bcast and not bool(lobby["guest_connected"]):
        _bc_timer -= delta
        if _bc_timer <= 0.0:
            _bc_timer = 1.0
            var packet := ("AETHER|%s|%d" % [room_name.substr(0, 32), GAME_PORT]).to_utf8_buffer()
            for target_ip in _broadcast_targets:
                _bcast.set_dest_address(target_ip, DISCOVERY_PORT)
                _bcast.put_packet(packet)
    if _listen:
        var changed := false
        while _listen.get_available_packet_count() > 0:
            var txt := _listen.get_packet().get_string_from_utf8()
            var ip := _listen.get_packet_ip()
            var parts := txt.split("|")
            if parts.size() == 3 and parts[0] == "AETHER":
                var port := int(parts[2])
                if port > 0 and port <= 65535 and ip != "":
                    rooms[ip] = {"name": parts[1].substr(0, 32), "port": port}
                    changed = true
        if changed:
            rooms_updated.emit()


# ---- eventos de red ----
func _on_peer_connected(id: int) -> void:
    if is_host:
        guest_id = id
        lobby["guest_connected"] = true
        _push_lobby()


func _on_peer_disconnected(_id: int) -> void:
    if is_host:
        lobby["guest_connected"] = false
        lobby["guest_ready"] = false
        lobby_updated.emit()
        disconnected.emit("El otro jugador se desconectó.")


func _on_connected() -> void:
    c_hello.rpc_id(1, player_name)
    status_changed.emit("Conectado. Entrando al lobby...")


func _on_failed() -> void:
    close()
    disconnected.emit("No se pudo conectar. Comprueba que ambos estén en la misma red Wi-Fi/hotspot y que el router no tenga aislamiento de clientes. Prueba la IP manual.")


func _on_server_gone() -> void:
    close()
    disconnected.emit("El anfitrión cerró la partida o se perdió la conexión.")


# ---- lobby ----
func _push_lobby() -> void:
    lobby_updated.emit()
    if is_host and guest_id != 0:
        s_lobby.rpc_id(guest_id, lobby)


func host_set(char_idx: int, arena: int) -> void:
    lobby["host_char"] = char_idx
    lobby["arena"] = arena
    _push_lobby()


func guest_set(char_idx: int, ready: bool) -> void:
    lobby["guest_char"] = char_idx
    lobby["guest_ready"] = ready
    c_set.rpc_id(1, char_idx, ready)


func host_start() -> void:
    if not is_host or not bool(lobby["guest_ready"]):
        return
    var cfg := GameManager.make_config("lan", int(lobby["host_char"]), int(lobby["guest_char"]), int(lobby["arena"]), 2)
    cfg["online"] = true
    cfg["time"] = 99.0
    GameManager.battle_config = cfg
    in_match = true
    s_start.rpc_id(guest_id, cfg)
    match_started.emit()


@rpc("any_peer", "call_remote", "reliable")
func c_hello(pname: String) -> void:
    if is_host:
        lobby["guest_name"] = pname
        _push_lobby()


@rpc("any_peer", "call_remote", "reliable")
func c_set(char_idx: int, ready: bool) -> void:
    if is_host:
        lobby["guest_char"] = clampi(char_idx, 0, GameManager.CHARACTERS.size() - 1)
        lobby["guest_ready"] = ready
        _push_lobby()


@rpc("authority", "call_remote", "reliable")
func s_lobby(l: Dictionary) -> void:
    lobby = l
    lobby_updated.emit()


@rpc("authority", "call_remote", "reliable")
func s_start(cfg: Dictionary) -> void:
    GameManager.battle_config = cfg
    in_match = true
    match_started.emit()


# ---- partida ----
@rpc("any_peer", "call_remote", "unreliable")
func send_input(d: Dictionary) -> void:
    if is_host:
        input_received.emit(d)


@rpc("authority", "call_remote", "unreliable")
func send_snapshot(d: Dictionary) -> void:
    snapshot_received.emit(d)


@rpc("authority", "call_remote", "reliable")
func send_fx(kind: String, d: Dictionary) -> void:
    fx_received.emit(kind, d)
