extends Control

signal navigate(id: String, args: Dictionary)

const UIKit = preload("res://scripts/ui/ui_kit.gd")
const FighterScript = preload("res://scripts/fighters/fighter.gd")

var args: Dictionary = {}
var _pivot: Node3D
var _cam: Camera3D
var _stats: Label
var _name: Label
var _sel := 0


func _ready() -> void:
    var c := UIKit.screen_base(self, "PERSONAJES")
    var row := HBoxContainer.new()
    row.size_flags_vertical = Control.SIZE_EXPAND_FILL
    row.add_theme_constant_override("separation", 16)
    c.add_child(row)
    var grid := GridContainer.new()
    grid.columns = 2
    grid.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    grid.add_theme_constant_override("h_separation", 8)
    grid.add_theme_constant_override("v_separation", 8)
    row.add_child(grid)
    for i in range(GameManager.CHARACTERS.size()):
        var ch: Dictionary = GameManager.CHARACTERS[i]
        var b := UIKit.button(str(ch["name"]), ch["color"].darkened(0.2), 52, 16)
        b.pressed.connect(_select.bind(i))
        grid.add_child(b)
    var right := VBoxContainer.new()
    right.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    row.add_child(right)
    var svc := SubViewportContainer.new()
    svc.stretch = true
    svc.custom_minimum_size = Vector2(0, 300)
    right.add_child(svc)
    var sv := SubViewport.new()
    sv.own_world_3d = true
    sv.transparent_bg = true
    svc.add_child(sv)
    _cam = Camera3D.new()
    sv.add_child(_cam)
    var sun := DirectionalLight3D.new()
    sun.rotation_degrees = Vector3(-40, 30, 0)
    sv.add_child(sun)
    var env := Environment.new()
    env.background_mode = Environment.BG_CLEAR_COLOR
    env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
    env.ambient_light_color = Color(0.6, 0.65, 0.8)
    var we := WorldEnvironment.new()
    we.environment = env
    sv.add_child(we)
    _pivot = Node3D.new()
    sv.add_child(_pivot)
    _name = UIKit.label("", 24, Color("#FFD77B"))
    right.add_child(_name)
    _stats = UIKit.label("", 15, Color("#cfe3ff"))
    right.add_child(_stats)
    var ok := UIKit.button("CONFIRMAR", Color("#22A879"), 54, 18)
    ok.pressed.connect(func():
        GameManager.selected_char = _sel
        navigate.emit("main", {}))
    right.add_child(ok)
    _select(GameManager.selected_char)


func _process(delta: float) -> void:
    if _pivot:
        _pivot.rotation.y += delta * 0.9


func _bars(v: float) -> String:
    return "|".repeat(clampi(int(round(v * 8.0)), 1, 16))


func _select(i: int) -> void:
    _sel = i
    var ch: Dictionary = GameManager.CHARACTERS[i]
    for old in _pivot.get_children():
        old.queue_free()
    var f = FighterScript.new()
    f.apply_character(ch)
    f.puppet = true
    _pivot.add_child(f)
    var s := float(ch["scale"])
    _cam.position = Vector3(0, 1.4 * s, 4.2 + 2.0 * s)
    _cam.look_at_from_position(_cam.position, Vector3(0, 1.0 * s, 0), Vector3.UP)
    _name.text = "%s - %s" % [ch["name"], ch["role"]]
    var fly := "Vuela" if bool(ch["fly"]) else "Solo terrestre"
    _stats.text = "VIDA   %s\nVELOC  %s\nPODER  %s\nENERG  %s\nKI     %s\n%s | Tamaño x%.2f" % [
        _bars(float(ch["hp"])), _bars(float(ch["speed"])), _bars(float(ch["power"])),
        _bars(float(ch["energy"]) / 100.0), _bars(float(ch["blast"])), fly, s]
