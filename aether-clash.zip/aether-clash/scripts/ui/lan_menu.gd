extends Control
# MULTIJUGADOR LAN: crear sala, buscar salas (broadcast UDP), conectar por IP, lobby.

signal navigate(id: String, args: Dictionary)

const UIKit = preload("res://scripts/ui/ui_kit.gd")

var args: Dictionary = {}
var content: VBoxContainer
var status: Label
var rooms_box: VBoxContainer
var _lobby_ui := false
var _l_host: Label
var _l_guest: Label
var _start_btn: Button
var _ready_btn: Button
var _ready_state := false
var _char_opt: OptionButton
var _arena_opt: OptionButton


func _ready() -> void:
    content = UIKit.screen_base(self, "MULTIJUGADOR LAN")
    NetworkManager.lobby_updated.connect(_refresh_lobby)
    NetworkManager.rooms_updated.connect(_refresh_rooms)
    NetworkManager.match_started.connect(_on_match)
    NetworkManager.disconnected.connect(_on_disc)
    NetworkManager.status_changed.connect(_set_status)
    _show_root()


func _exit_tree() -> void:
    if not NetworkManager.in_match:
        NetworkManager.close()


func _set_status(t: String) -> void:
    if status:
        status.text = t
    if t.begins_with("Conectado") and not _lobby_ui:
        _show_lobby(false)


func _clear() -> void:
    for ch in content.get_children():
        ch.queue_free()


func _show_root() -> void:
    _lobby_ui = false
    _clear()
    var ips := NetworkManager.local_ips()
    content.add_child(UIKit.label("Tu IP local: %s   Puerto UDP: %d" % [", ".join(ips) if not ips.is_empty() else "sin Wi-Fi detectado", NetworkManager.GAME_PORT], 17, Color("#FFD77B")))
    content.add_child(UIKit.label("Funciona sin internet: ambos dispositivos deben estar en la misma Wi-Fi o hotspot. Permite UDP %d y %d en el firewall." % [NetworkManager.GAME_PORT, NetworkManager.DISCOVERY_PORT], 14, Color("#9fb7d9")))
    var name_edit := LineEdit.new()
    name_edit.text = NetworkManager.player_name
    name_edit.custom_minimum_size = Vector2(0, 44)
    name_edit.text_changed.connect(func(t: String): NetworkManager.player_name = t)
    content.add_child(UIKit.row("Tu nombre", name_edit))
    var create := UIKit.button("CREAR PARTIDA", Color("#22A879"), 56, 18)
    create.pressed.connect(func():
        if NetworkManager.host_create():
            _show_lobby(true))
    content.add_child(create)
    var search := UIKit.button("BUSCAR PARTIDAS LOCALES", Color("#267CCB"), 56, 18)
    search.pressed.connect(func():
        NetworkManager.start_search()
        _set_status("Buscando salas en la red local...")
        _refresh_rooms())
    content.add_child(search)
    rooms_box = VBoxContainer.new()
    rooms_box.add_theme_constant_override("separation", 6)
    content.add_child(rooms_box)
    var ip_edit := LineEdit.new()
    ip_edit.placeholder_text = "192.168.43.1"
    ip_edit.custom_minimum_size = Vector2(0, 44)
    content.add_child(UIKit.row("IP del anfitrión", ip_edit))
    var conn := UIKit.button("CONECTAR POR IP", Color("#9360D4"), 52, 17)
    conn.pressed.connect(func():
        var ip := ip_edit.text.strip_edges()
        if ip == "":
            _set_status("Escribe la IP del anfitrión.")
        else:
            NetworkManager.join(ip, NetworkManager.GAME_PORT))
    content.add_child(conn)
    status = UIKit.label("Si el descubrimiento no encuentra salas, usa la IP manual (algunos hotspots y routers aíslan los dispositivos).", 15, Color("#9fb7d9"))
    content.add_child(status)


func _refresh_rooms() -> void:
    if rooms_box == null or _lobby_ui:
        return
    for ch in rooms_box.get_children():
        ch.queue_free()
    for ip in NetworkManager.rooms.keys():
        var r: Dictionary = NetworkManager.rooms[ip]
        var b := UIKit.button("%s  (%s)" % [r["name"], ip], Color("#438BBA"), 48, 16)
        b.pressed.connect(func(): NetworkManager.join(str(ip), int(r["port"])))
        rooms_box.add_child(b)


func _show_lobby(host: bool) -> void:
    NetworkManager.stop_search()
    _lobby_ui = true
    _clear()
    content.add_child(UIKit.label("SALA: %s  |  Estado: %s" % [NetworkManager.room_name, "ANFITRIÓN" if host else "INVITADO"], 18, Color("#FFD77B")))
    _l_host = UIKit.label("", 18)
    _l_guest = UIKit.label("", 18)
    content.add_child(_l_host)
    content.add_child(_l_guest)
    var names: Array = []
    for ch in GameManager.CHARACTERS:
        names.append("%s (%s)" % [ch["name"], ch["role"]])
    _char_opt = UIKit.option(names, GameManager.selected_char if host else 1)
    content.add_child(UIKit.row("Tu personaje", _char_opt))
    if host:
        var arenas: Array = []
        for a in GameManager.ARENAS:
            arenas.append(str(a["name"]))
        _arena_opt = UIKit.option(arenas, 0)
        content.add_child(UIKit.row("Escenario", _arena_opt))
        _char_opt.item_selected.connect(func(_i: int): NetworkManager.host_set(_char_opt.selected, _arena_opt.selected))
        _arena_opt.item_selected.connect(func(_i: int): NetworkManager.host_set(_char_opt.selected, _arena_opt.selected))
        _start_btn = UIKit.button("INICIAR", Color("#22A879"), 60, 20)
        _start_btn.disabled = true
        _start_btn.pressed.connect(func(): NetworkManager.host_start())
        content.add_child(_start_btn)
        NetworkManager.host_set(_char_opt.selected, _arena_opt.selected)
    else:
        _char_opt.item_selected.connect(func(_i: int):
            _ready_state = false
            NetworkManager.guest_set(_char_opt.selected, false)
            _ready_btn.text = "LISTO")
        _ready_btn = UIKit.button("LISTO", Color("#22A879"), 60, 20)
        _ready_btn.pressed.connect(func():
            _ready_state = not _ready_state
            _ready_btn.text = "CANCELAR LISTO" if _ready_state else "LISTO"
            NetworkManager.guest_set(_char_opt.selected, _ready_state))
        content.add_child(_ready_btn)
        NetworkManager.guest_set(_char_opt.selected, false)
    status = UIKit.label("Conectado.", 15, Color("#9fb7d9"))
    content.add_child(status)
    _refresh_lobby()


func _refresh_lobby() -> void:
    if not _lobby_ui or _l_host == null:
        return
    var l: Dictionary = NetworkManager.lobby
    var hc: Dictionary = GameManager.CHARACTERS[int(l["host_char"])]
    var gc: Dictionary = GameManager.CHARACTERS[int(l["guest_char"])]
    _l_host.text = "Anfitrión: %s  -  %s" % [str(l["host_name"]), hc["name"]]
    if bool(l["guest_connected"]):
        _l_guest.text = "Invitado: %s  -  %s  -  %s" % [str(l["guest_name"]), gc["name"], "LISTO" if bool(l["guest_ready"]) else "no listo"]
    else:
        _l_guest.text = "Invitado: esperando..."
    if _start_btn:
        _start_btn.disabled = not (bool(l["guest_connected"]) and bool(l["guest_ready"]))


func _on_match() -> void:
    navigate.emit("fight", {"cfg": GameManager.battle_config})


func _on_disc(reason: String) -> void:
    _show_root()
    _set_status(reason)
