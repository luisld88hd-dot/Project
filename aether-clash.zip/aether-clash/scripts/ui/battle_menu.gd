extends Control
# Sirve para COMBATE, ENTRENAMIENTO, SUPERVIVENCIA y TORNEO (args.mode).

signal navigate(id: String, args: Dictionary)

const UIKit = preload("res://scripts/ui/ui_kit.gd")

var args: Dictionary = {}


func _ready() -> void:
    var mode := str(args.get("mode", "battle"))
    var titles := {"battle": "COMBATE LIBRE", "training": "ENTRENAMIENTO", "survival": "SUPERVIVENCIA", "tournament": "TORNEO"}
    var c := UIKit.screen_base(self, str(titles.get(mode, "COMBATE")))
    var names: Array = []
    for ch in GameManager.CHARACTERS:
        names.append("%s  (%s)" % [ch["name"], ch["role"]])
    var arena_names: Array = []
    for a in GameManager.ARENAS:
        arena_names.append("%s%s" % [a["name"], "  [caída = derrota]" if a["ringout"] else ""])
    var p_opt := UIKit.option(names, GameManager.selected_char)
    c.add_child(UIKit.row("Tu personaje", p_opt))
    var e_opt: OptionButton = null
    if mode == "battle" or mode == "training":
        var rn: Array = ["Aleatorio"]
        rn.append_array(names)
        e_opt = UIKit.option(rn, 0)
        c.add_child(UIKit.row("Rival", e_opt))
    var a_opt := UIKit.option(arena_names, 0)
    c.add_child(UIKit.row("Escenario", a_opt))
    var d_opt: OptionButton = null
    var t_opt: OptionButton = null
    var m_opt: OptionButton = null
    if mode != "training":
        d_opt = UIKit.option(GameManager.DIFFICULTIES, 2)
        c.add_child(UIKit.row("Dificultad IA", d_opt))
    if mode == "battle":
        t_opt = UIKit.option(["60 s", "99 s", "180 s", "Sin límite"], 1)
        c.add_child(UIKit.row("Tiempo", t_opt))
    if mode == "training":
        m_opt = UIKit.option(["Rival inmóvil", "Rival que defiende", "Rival que ataca"], 0)
        c.add_child(UIKit.row("Rival entrenamiento", m_opt))
    var info := UIKit.label("", 15, Color("#9fb7d9"))
    match mode:
        "survival": info.text = "Oleadas infinitas con rivales cada vez más fuertes. Recuperas algo de vida entre oleadas."
        "tournament": info.text = "3 rondas eliminatorias contra rivales y escenarios aleatorios con dificultad creciente."
        "training": info.text = "Salud y energía infinitas. Practica combos, vuelo y técnicas."
    c.add_child(info)
    var go_btn := UIKit.button("INICIAR", Color("#22A879"), 60, 20)
    c.add_child(go_btn)
    go_btn.pressed.connect(func():
        var pc := p_opt.selected
        GameManager.selected_char = pc
        var ec := randi() % GameManager.CHARACTERS.size()
        if e_opt != null and e_opt.selected > 0:
            ec = e_opt.selected - 1
        var lvl := d_opt.selected if d_opt != null else 2
        var cfg := GameManager.make_config(mode, pc, ec, a_opt.selected, lvl)
        if t_opt != null:
            cfg["time"] = [60.0, 99.0, 180.0, -1.0][t_opt.selected]
        if mode == "training":
            cfg["time"] = -1.0
            cfg["ai_mode"] = [-1, 0, 1][m_opt.selected]
            cfg["level"] = 2
        if mode == "survival":
            cfg["time"] = -1.0
            cfg["level"] = mini(lvl, 2)
        navigate.emit("fight", {"cfg": cfg}))
