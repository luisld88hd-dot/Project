extends Control
# Editor sencillo con plantillas. Guarda JSON versionado en user://custom/

signal navigate(id: String, args: Dictionary)

const UIKit = preload("res://scripts/ui/ui_kit.gd")

var args: Dictionary = {}
var _list: VBoxContainer


func _ready() -> void:
    var c := UIKit.screen_base(self, "COMBATES PERSONALIZADOS")
    var names: Array = []
    for ch in GameManager.CHARACTERS:
        names.append(str(ch["name"]))
    var arenas: Array = []
    for a in GameManager.ARENAS:
        arenas.append(str(a["name"]))
    var title := LineEdit.new()
    title.placeholder_text = "Título del combate"
    title.text = "Mi combate"
    title.custom_minimum_size = Vector2(0, 46)
    c.add_child(UIKit.row("Título", title))
    var tmpl := UIKit.option(["Duelo de rivales", "Jefe final", "Batalla con tiempo límite", "Duelo con vida baja"], 0)
    c.add_child(UIKit.row("Plantilla", tmpl))
    var p := UIKit.option(names, GameManager.selected_char)
    c.add_child(UIKit.row("Tu personaje", p))
    var e := UIKit.option(names, 1)
    c.add_child(UIKit.row("Rival", e))
    var a := UIKit.option(arenas, 0)
    c.add_child(UIKit.row("Escenario", a))
    var lvl := UIKit.option(GameManager.DIFFICULTIES, 2)
    c.add_child(UIKit.row("Dificultad", lvl))
    var ehp := UIKit.option(["Vida rival x0.5", "Vida rival x1", "Vida rival x2", "Vida rival x3"], 1)
    c.add_child(UIKit.row("Vida rival", ehp))
    var tm := UIKit.option(["30 s", "60 s", "99 s", "180 s"], 2)
    c.add_child(UIKit.row("Tiempo", tm))
    tmpl.item_selected.connect(func(i: int):
        match i:
            1:
                ehp.select(3)
                lvl.select(3)
                tm.select(3)
            2:
                tm.select(0)
            3:
                ehp.select(0)
                tm.select(1))
    var save := UIKit.button("GUARDAR COMBATE", Color("#22A879"), 52, 18)
    save.pressed.connect(func():
        var cfg := GameManager.make_config("custom", p.selected, e.selected, a.selected, lvl.selected)
        cfg["enemy_hp"] = [0.5, 1.0, 2.0, 3.0][ehp.selected]
        cfg["time"] = [30.0, 60.0, 99.0, 180.0][tm.selected]
        SaveManager.save_custom(title.text, cfg)
        _refresh())
    c.add_child(save)
    c.add_child(UIKit.label("COMBATES GUARDADOS", 20, Color("#FFD77B")))
    _list = VBoxContainer.new()
    _list.add_theme_constant_override("separation", 8)
    c.add_child(_list)
    _refresh()


func _refresh() -> void:
    for ch in _list.get_children():
        ch.queue_free()
    var items := SaveManager.list_custom()
    if items.is_empty():
        _list.add_child(UIKit.label("Aún no hay combates guardados.", 15, Color("#9fb7d9")))
    for it in items:
        var h := HBoxContainer.new()
        var play := UIKit.button(str(it["title"]), Color("#267CCB"), 48, 16)
        play.pressed.connect(func(): navigate.emit("fight", {"cfg": it["cfg"]}))
        h.add_child(play)
        var del := UIKit.button("BORRAR", Color("#BC4F5D"), 48, 14)
        del.size_flags_horizontal = Control.SIZE_SHRINK_END
        del.custom_minimum_size = Vector2(120, 48)
        del.pressed.connect(func():
            SaveManager.delete_custom(str(it["file"]))
            _refresh())
        h.add_child(del)
        _list.add_child(h)
