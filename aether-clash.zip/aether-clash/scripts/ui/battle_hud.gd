extends Control

signal action_pressed(action: String)
signal pause_requested

const UIKit = preload("res://scripts/ui/ui_kit.gd")

var _sides: Array = []
var _timer: Label
var _info: Label
var _msg: Label
var _combo: Label
var _overlay: Control
var _msg_tween: Tween


func _ready() -> void:
    set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    mouse_filter = Control.MOUSE_FILTER_IGNORE
    process_mode = Node.PROCESS_MODE_ALWAYS
    var margin := MarginContainer.new()
    margin.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    margin.mouse_filter = Control.MOUSE_FILTER_IGNORE
    for s in ["left", "right", "top"]:
        margin.add_theme_constant_override("margin_" + s, 16)
    add_child(margin)
    var top := HBoxContainer.new()
    top.mouse_filter = Control.MOUSE_FILTER_IGNORE
    top.size_flags_vertical = Control.SIZE_SHRINK_BEGIN
    margin.add_child(top)
    _sides.append(_build_side(top, Color("#ff5a3c")))
    var center := VBoxContainer.new()
    center.mouse_filter = Control.MOUSE_FILTER_IGNORE
    center.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    center.size_flags_stretch_ratio = 0.5
    top.add_child(center)
    _timer = UIKit.label("99", 36, Color("#FFD77B"))
    _timer.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    center.add_child(_timer)
    _info = UIKit.label("", 15, Color("#cfe3ff"))
    _info.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    center.add_child(_info)
    var pause := UIKit.button("II PAUSA", Color("#344B68"), 36, 14)
    pause.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
    pause.custom_minimum_size = Vector2(120, 36)
    pause.pressed.connect(func(): pause_requested.emit())
    center.add_child(pause)
    _sides.append(_build_side(top, Color("#ff5a3c")))
    _msg = UIKit.label("", 34, Color("#FFD77B"))
    _msg.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    _msg.custom_minimum_size = Vector2(600, 0)
    _msg.set_anchors_and_offsets_preset(Control.PRESET_CENTER_TOP, Control.PRESET_MODE_MINSIZE)
    _msg.offset_top += 170.0
    _msg.offset_bottom += 170.0
    _msg.mouse_filter = Control.MOUSE_FILTER_IGNORE
    add_child(_msg)
    _combo = UIKit.label("", 30, Color("#ff9a3c"))
    _combo.custom_minimum_size = Vector2(230, 0)
    _combo.set_anchors_and_offsets_preset(Control.PRESET_CENTER_RIGHT, Control.PRESET_MODE_MINSIZE)
    _combo.offset_left -= 30.0
    _combo.offset_right -= 30.0
    _combo.offset_top -= 160.0
    _combo.offset_bottom -= 160.0
    _combo.mouse_filter = Control.MOUSE_FILTER_IGNORE
    add_child(_combo)


func _build_side(parent: Control, hp_color: Color) -> Dictionary:
    var panel := PanelContainer.new()
    panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
    panel.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    panel.add_theme_stylebox_override("panel", UIKit.box(Color(0.02, 0.06, 0.14, 0.7), 12, Color("#FFD77B"), 2))
    parent.add_child(panel)
    var v := VBoxContainer.new()
    v.mouse_filter = Control.MOUSE_FILTER_IGNORE
    v.add_theme_constant_override("separation", 3)
    panel.add_child(v)
    var name_l := UIKit.label("---", 18, Color.WHITE)
    v.add_child(name_l)
    var hp := UIKit.bar(hp_color, 20)
    v.add_child(hp)
    var en := UIKit.bar(Color("#3aa7ff"), 12)
    v.add_child(en)
    var ki := UIKit.label("KI x0", 14, Color("#FFD77B"))
    v.add_child(ki)
    return {"name": name_l, "hp": hp, "en": en, "ki": ki}


func _set_side(i: int, f) -> void:
    var s: Dictionary = _sides[i]
    s["name"].text = str(f.display_name)
    s["hp"].max_value = f.max_hp
    s["hp"].value = f.hp
    s["en"].max_value = f.max_energy
    s["en"].value = f.energy
    s["ki"].text = "KI x%d%s" % [mini(3, int(f.ki_meter / 100.0)), "   AGOTADO" if f.exhausted else ""]


func update_hud(p, e, time_left: float, info: String) -> void:
    _set_side(0, p)
    _set_side(1, e)
    _timer.text = "--" if time_left < 0.0 else str(int(ceil(time_left)))
    _info.text = info
    _combo.text = ("%d GOLPES" % p.combo) if p.combo > 1 else ""


func show_message(text: String, secs: float = 1.4) -> void:
    _msg.text = text
    _msg.modulate.a = 1.0
    if _msg_tween:
        _msg_tween.kill()
    _msg_tween = create_tween()
    _msg_tween.tween_interval(secs)
    _msg_tween.tween_property(_msg, "modulate:a", 0.0, 0.4)


func clear_overlay() -> void:
    if _overlay:
        _overlay.queue_free()
        _overlay = null


# buttons: Array de [texto, accion, color]
func show_overlay(title: String, subtitle: String, buttons: Array) -> void:
    clear_overlay()
    _overlay = Control.new()
    _overlay.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    add_child(_overlay)
    var dim := ColorRect.new()
    dim.color = Color(0, 0, 0, 0.6)
    dim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    _overlay.add_child(dim)
    var center := CenterContainer.new()
    center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    _overlay.add_child(center)
    var panel := PanelContainer.new()
    panel.custom_minimum_size = Vector2(520, 0)
    panel.add_theme_stylebox_override("panel", UIKit.box(Color(0.03, 0.08, 0.17, 0.96), 20, Color("#FFD77B"), 3))
    center.add_child(panel)
    var v := VBoxContainer.new()
    v.add_theme_constant_override("separation", 10)
    panel.add_child(v)
    var t := UIKit.label(title, 40, Color("#FFD77B"))
    t.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    v.add_child(t)
    if subtitle != "":
        var s := UIKit.label(subtitle, 17, Color("#E2EEFF"))
        s.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
        v.add_child(s)
    for b in buttons:
        var btn := UIKit.button(str(b[0]), b[2], 50, 18)
        btn.pressed.connect(func(): action_pressed.emit(str(b[1])))
        v.add_child(btn)
