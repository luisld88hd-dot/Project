extends Control

const STICK_R := 110.0

var move := Vector2.ZERO
var held := {"guard": false, "charge": false, "up": false, "down": false, "attack": false, "blast": false}
var pending := {"attack": false, "heavy": false, "blast": false, "dash": false, "ult": false, "spark": false}
var counts := {"attack": 0, "heavy": 0, "blast": 0, "dash": 0, "ult": 0, "spark": 0}
var fighter = null   # luchador local (para atenuar botones no disponibles)
var btn_scale := 1.0
var opacity := 0.7
var _touch_btn := {}
var _stick_index := -1
var _stick_origin := Vector2.ZERO
var _stick_pos := Vector2.ZERO
var edit_mode := false
var _drag_button := ""


func _ready() -> void:
    set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    mouse_filter = Control.MOUSE_FILTER_IGNORE
    var s: Dictionary = SaveManager.data["settings"]
    btn_scale = float(s["btn_scale"])
    opacity = float(s["opacity"])
    edit_mode = bool(s.get("edit_controls", false))


func _layout() -> Dictionary:
    var r := size
    var k := btn_scale
    var layout := {
        "attack": {"pos": Vector2(r.x - 130, r.y - 140), "r": 75.0 * k, "text": "GOLPE", "color": Color("#E07B2F")},
        "heavy": {"pos": Vector2(r.x - 270, r.y - 215), "r": 58.0 * k, "text": "FUERTE", "color": Color("#C4452B")},
        "blast": {"pos": Vector2(r.x - 290, r.y - 90), "r": 55.0 * k, "text": "KI", "color": Color("#267CCB")},
        "guard": {"pos": Vector2(r.x - 110, r.y - 300), "r": 50.0 * k, "text": "GUARDIA", "color": Color("#22A879")},
        "dash": {"pos": Vector2(r.x - 250, r.y - 345), "r": 50.0 * k, "text": "DASH", "color": Color("#9360D4")},
        "ult": {"pos": Vector2(r.x - 250, r.y - 450), "r": 44.0 * k, "text": "ULTI", "color": Color("#D13A5A")},
        "spark": {"pos": Vector2(r.x - 395, r.y - 330), "r": 46.0 * k, "text": "SPARKING", "color": Color("#FF8A1F")},
        "up": {"pos": Vector2(r.x - 430, r.y - 170), "r": 46.0 * k, "text": "SUBIR", "color": Color("#438BBA")},
        "down": {"pos": Vector2(r.x - 430, r.y - 60), "r": 44.0 * k, "text": "BAJAR", "color": Color("#438BBA")},
        "charge": {"pos": Vector2(r.x - 570, r.y - 80), "r": 44.0 * k, "text": "CARGA", "color": Color("#C9A227")}
    }
    var saved: Dictionary = SaveManager.data["settings"].get("button_positions", {})
    for key in layout.keys():
        if saved.has(key) and saved[key] is Array and saved[key].size() == 2:
            layout[key]["pos"] = Vector2(float(saved[key][0]) * r.x, float(saved[key][1]) * r.y)
    return layout


# Botones sin recurso suficiente se dibujan atenuados.
func _is_ready(k: String) -> bool:
    if fighter == null or not is_instance_valid(fighter):
        return true
    match k:
        "ult":
            return fighter.ki_meter >= 200.0
        "spark":
            return (not fighter.spark_used) and fighter.ki_meter >= 100.0
        "dash", "heavy", "blast":
            return not fighter.exhausted
    return true


func _hit_button(p: Vector2) -> String:
    var lay := _layout()
    for k in lay.keys():
        if p.distance_to(lay[k]["pos"]) <= float(lay[k]["r"]) * 1.1:
            return k
    return ""


func _save_button_positions() -> void:
    SaveManager.save()


func _press(bn: String) -> void:
    if pending.has(bn):
        pending[bn] = true
    if held.has(bn):
        held[bn] = true


func _release(bn: String) -> void:
    if held.has(bn):
        held[bn] = false


func _input(event: InputEvent) -> void:
    if event is InputEventScreenTouch:
        var pos: Vector2 = event.position
        if event.pressed:
            var bn := _hit_button(pos)
            if bn != "":
                if edit_mode:
                    _drag_button = bn
                    _touch_btn[event.index] = "EDIT:" + bn
                else:
                    _touch_btn[event.index] = bn
                    _press(bn)
            elif pos.x < size.x * 0.45 and _stick_index == -1:
                _stick_index = event.index
                _stick_origin = pos
                _stick_pos = pos
                move = Vector2.ZERO
        else:
            if _touch_btn.has(event.index):
                var released: String = _touch_btn[event.index]
                if released.begins_with("EDIT:"):
                    _save_button_positions()
                    _drag_button = ""
                else:
                    _release(released)
                _touch_btn.erase(event.index)
            elif event.index == _stick_index:
                _stick_index = -1
                move = Vector2.ZERO
    elif event is InputEventScreenDrag:
        if _drag_button != "":
            var lay := _layout()
            lay[_drag_button]["pos"] = event.position
            var saved: Dictionary = SaveManager.data["settings"].get("button_positions", {})
            saved[_drag_button] = [event.position.x / maxf(size.x, 1.0), event.position.y / maxf(size.y, 1.0)]
            SaveManager.data["settings"]["button_positions"] = saved
        elif event.index == _stick_index:
            _stick_pos = event.position
            move = ((_stick_pos - _stick_origin) / STICK_R).limit_length(1.0)
    elif event is InputEventKey and event.pressed and not event.echo:
        match event.keycode:
            KEY_J:
                pending["attack"] = true
            KEY_H:
                pending["heavy"] = true
            KEY_P:
                pending["spark"] = true
            KEY_K:
                pending["blast"] = true
            KEY_I:
                pending["dash"] = true
            KEY_U:
                pending["ult"] = true


func get_intent() -> Dictionary:
    var mv := move
    var kx := 0.0
    var ky := 0.0
    if Input.is_key_pressed(KEY_A): kx -= 1.0
    if Input.is_key_pressed(KEY_D): kx += 1.0
    if Input.is_key_pressed(KEY_W): ky -= 1.0
    if Input.is_key_pressed(KEY_S): ky += 1.0
    if kx != 0.0 or ky != 0.0:
        mv = Vector2(kx, ky).normalized()
    var up := 0.0
    if held["up"] or Input.is_key_pressed(KEY_SPACE):
        up += 1.0
    if held["down"] or Input.is_key_pressed(KEY_CTRL):
        up -= 1.0
    var it := {
        "move": mv, "up": up,
        "guard": held["guard"] or Input.is_key_pressed(KEY_L),
        "charge": held["charge"] or Input.is_key_pressed(KEY_O),
        "attack": false, "heavy": false, "blast": false, "dash": false, "ult": false, "spark": false
    }
    for k in pending.keys():
        var fire: bool = pending[k] or ((k == "attack" or k == "blast") and held[k])
        if fire:
            it[k] = true
            counts[k] += 1
            pending[k] = false
    return it


func _process(_delta: float) -> void:
    queue_redraw()


func _draw() -> void:
    var a := opacity
    if _stick_index != -1:
        draw_circle(_stick_origin, STICK_R, Color(1, 1, 1, 0.12 * a))
        var knob := _stick_origin + (_stick_pos - _stick_origin).limit_length(STICK_R)
        draw_circle(knob, 44.0, Color(1, 1, 1, 0.45 * a))
    else:
        var c := Vector2(170, size.y - 170)
        draw_circle(c, STICK_R, Color(1, 1, 1, 0.08 * a))
        draw_arc(c, STICK_R, 0, TAU, 40, Color(1, 1, 1, 0.3 * a), 3.0)
    var lay := _layout()
    var down_btns := _touch_btn.values()
    for k in lay.keys():
        var d: Dictionary = lay[k]
        var col: Color = d["color"]
        var pressed := down_btns.has(k)
        var dim := 1.0 if _is_ready(k) else 0.35
        draw_circle(d["pos"], d["r"], Color(col.r, col.g, col.b, (0.85 if pressed else 0.5) * a * dim))
        if edit_mode:
            draw_arc(d["pos"], d["r"] + 8.0, 0, TAU, 40, Color("#FFD77B"), 3.0)
        draw_arc(d["pos"], d["r"], 0, TAU, 40, Color(1, 1, 1, 0.7 * a * dim), 3.0)
        var r: float = d["r"]
        var p: Vector2 = d["pos"]
        draw_string(ThemeDB.fallback_font, Vector2(p.x - r, p.y + 6), str(d["text"]), HORIZONTAL_ALIGNMENT_CENTER, r * 2.0, 15, Color(1, 1, 1, dim))
