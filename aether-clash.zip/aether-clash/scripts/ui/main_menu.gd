extends Control
# Basado en el ejemplo del superprompt, adaptado a horizontal (título a la izquierda, rejilla a la derecha).

signal navigation_requested(screen_id: String)

const UIKit = preload("res://scripts/ui/ui_kit.gd")

const MENU_ITEMS: Array[Dictionary] = [
    {"label": "HISTORIA", "id": "story", "color": Color("#C58B35")},
    {"label": "COMBATE", "id": "battle", "color": Color("#267CCB")},
    {"label": "MULTIJUGADOR LAN", "id": "lan", "color": Color("#22A879")},
    {"label": "TORNEO", "id": "tournament", "color": Color("#9360D4")},
    {"label": "ENTRENAMIENTO", "id": "training", "color": Color("#438BBA")},
    {"label": "COMBATES PERSONALIZADOS", "id": "custom", "color": Color("#D17A36")},
    {"label": "SUPERVIVENCIA", "id": "survival", "color": Color("#BC4F5D")},
    {"label": "PERSONAJES", "id": "characters", "color": Color("#4269C8")},
    {"label": "CONFIGURACIÓN", "id": "settings", "color": Color("#344B68")}
]


func _ready() -> void:
    set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    var overlay := ColorRect.new()
    overlay.color = Color(0.015, 0.035, 0.09, 0.30)
    overlay.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    overlay.mouse_filter = Control.MOUSE_FILTER_IGNORE
    add_child(overlay)
    var margin := MarginContainer.new()
    margin.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    for s in ["left", "right", "top", "bottom"]:
        margin.add_theme_constant_override("margin_" + s, 28)
    add_child(margin)
    var row := HBoxContainer.new()
    row.add_theme_constant_override("separation", 24)
    margin.add_child(row)
    var left := VBoxContainer.new()
    left.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    left.alignment = BoxContainer.ALIGNMENT_BEGIN
    row.add_child(left)
    var title := UIKit.label("AETHER CLASH", 54, Color("#FFD77B"))
    title.add_theme_color_override("font_outline_color", Color("#06152E"))
    title.add_theme_constant_override("outline_size", 10)
    left.add_child(title)
    var sub := UIKit.label("LEGENDS OF KI", 28, Color("#E2EEFF"))
    left.add_child(sub)
    var panel := PanelContainer.new()
    panel.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    panel.size_flags_stretch_ratio = 1.1
    panel.size_flags_vertical = Control.SIZE_SHRINK_CENTER
    panel.add_theme_stylebox_override("panel", UIKit.box(Color(0.025, 0.07, 0.15, 0.93), 20))
    row.add_child(panel)
    var grid := GridContainer.new()
    grid.columns = 2
    grid.add_theme_constant_override("h_separation", 10)
    grid.add_theme_constant_override("v_separation", 10)
    panel.add_child(grid)
    for item in MENU_ITEMS:
        var b := UIKit.button(str(item["label"]), item["color"], 56, 15)
        b.pressed.connect(func(): navigation_requested.emit(str(item["id"])))
        grid.add_child(b)
