extends Control

signal navigate(id: String, args: Dictionary)

const UIKit = preload("res://scripts/ui/ui_kit.gd")

var args: Dictionary = {}
var _detail: VBoxContainer


func _ready() -> void:
    var c := UIKit.screen_base(self, "CRÓNICAS DEL NÚCLEO AETHER")
    var info := UIKit.label("Personaje: %s. Termina cada capítulo para desbloquear el siguiente. En el capítulo 3 eliges ruta." % GameManager.CHARACTERS[GameManager.selected_char]["name"], 15, Color("#9fb7d9"))
    c.add_child(info)
    var progress := int(SaveManager.data["story_progress"])
    for i in range(GameManager.STORY.size()):
        var b := UIKit.button(str(GameManager.STORY[i]["title"]), Color("#C58B35"), 50, 17)
        b.disabled = i > progress
        b.pressed.connect(_show_chapter.bind(i))
        c.add_child(b)
    _detail = VBoxContainer.new()
    _detail.add_theme_constant_override("separation", 8)
    c.add_child(_detail)


func _show_chapter(i: int) -> void:
    for ch in _detail.get_children():
        ch.queue_free()
    var st: Dictionary = GameManager.STORY[i]
    _detail.add_child(HSeparator.new())
    _detail.add_child(UIKit.label(str(st["text"]), 17))
    if st.has("choices"):
        var cur := UIKit.label("Ruta actual: %s" % str(SaveManager.data["branch"]), 16, Color("#FFD77B"))
        _detail.add_child(cur)
        for opt in st["choices"]:
            var b := UIKit.button(str(opt["label"]), Color("#9360D4"), 46, 16)
            b.pressed.connect(func():
                SaveManager.data["branch"] = str(opt["branch"])
                SaveManager.save()
                cur.text = "Ruta actual: %s" % str(opt["branch"]))
            _detail.add_child(b)
    var fight := UIKit.button("COMBATIR", Color("#22A879"), 56, 20)
    fight.pressed.connect(func():
        var cfg := GameManager.story_config(i, GameManager.selected_char)
        navigate.emit("fight", {"cfg": cfg}))
    _detail.add_child(fight)
