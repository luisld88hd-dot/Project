extends RefCounted

static func box(color: Color, radius: int = 12, border: Color = Color(0, 0, 0, 0), border_w: int = 0) -> StyleBoxFlat:
    var s := StyleBoxFlat.new()
    s.bg_color = color
    s.set_corner_radius_all(radius)
    s.set_border_width_all(border_w)
    s.border_color = border
    s.content_margin_left = 14
    s.content_margin_right = 14
    s.content_margin_top = 8
    s.content_margin_bottom = 8
    s.shadow_size = 4
    s.shadow_color = Color(0, 0, 0, 0.3)
    s.shadow_offset = Vector2(0, 3)
    return s


static func button(text: String, color: Color, min_h: float = 52.0, font_size: int = 16) -> Button:
    var b := Button.new()
    b.text = text
    b.custom_minimum_size = Vector2(0, min_h)
    b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    b.add_theme_font_size_override("font_size", font_size)
    for c in ["font_color", "font_hover_color", "font_pressed_color", "font_focus_color", "font_disabled_color"]:
        b.add_theme_color_override(c, Color.WHITE)
    b.add_theme_stylebox_override("normal", box(color))
    b.add_theme_stylebox_override("hover", box(color.lightened(0.16)))
    b.add_theme_stylebox_override("pressed", box(color.darkened(0.18)))
    b.add_theme_stylebox_override("focus", box(color.lightened(0.16)))
    b.add_theme_stylebox_override("disabled", box(color.darkened(0.55)))
    return b


static func label(text: String, size: int = 16, color: Color = Color.WHITE) -> Label:
    var l := Label.new()
    l.text = text
    l.add_theme_font_size_override("font_size", size)
    l.add_theme_color_override("font_color", color)
    l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    return l


static func option(items: Array, selected: int = 0) -> OptionButton:
    var o := OptionButton.new()
    o.custom_minimum_size = Vector2(0, 46)
    o.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    o.add_theme_font_size_override("font_size", 17)
    var pop := o.get_popup()
    pop.add_theme_font_size_override("font_size", 20)
    pop.add_theme_constant_override("v_separation", 14)
    for it in items:
        o.add_item(str(it))
    o.select(clampi(selected, 0, maxi(items.size() - 1, 0)))
    return o


static func row(caption: String, control: Control) -> HBoxContainer:
    var h := HBoxContainer.new()
    var l := label(caption, 16, Color("#cfe3ff"))
    l.custom_minimum_size = Vector2(200, 0)
    h.add_child(l)
    control.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    h.add_child(control)
    return h


static func bar(color: Color, height: float = 18.0) -> ProgressBar:
    var p := ProgressBar.new()
    p.show_percentage = false
    p.custom_minimum_size = Vector2(0, height)
    p.add_theme_stylebox_override("fill", box(color, 6))
    p.add_theme_stylebox_override("background", box(Color(0, 0, 0, 0.55), 6))
    return p


# Fondo + cabecera con botón VOLVER. Devuelve el contenedor de contenido (con scroll).
static func screen_base(host: Control, title: String, back_id: String = "main") -> VBoxContainer:
    host.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    var bg := ColorRect.new()
    bg.color = Color(0.02, 0.05, 0.12, 0.88)
    bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    host.add_child(bg)
    var margin := MarginContainer.new()
    margin.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    margin.add_theme_constant_override("margin_left", 28)
    margin.add_theme_constant_override("margin_right", 28)
    margin.add_theme_constant_override("margin_top", 14)
    margin.add_theme_constant_override("margin_bottom", 14)
    host.add_child(margin)
    var root := VBoxContainer.new()
    root.add_theme_constant_override("separation", 10)
    margin.add_child(root)
    var head := HBoxContainer.new()
    root.add_child(head)
    var back := button("< VOLVER", Color("#344B68"), 44, 15)
    back.size_flags_horizontal = Control.SIZE_SHRINK_BEGIN
    back.custom_minimum_size = Vector2(150, 44)
    back.pressed.connect(func(): host.emit_signal("navigate", back_id, {}))
    head.add_child(back)
    var t := label(title, 28, Color("#FFD77B"))
    t.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    t.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    head.add_child(t)
    var spacer := Control.new()
    spacer.custom_minimum_size = Vector2(150, 0)
    head.add_child(spacer)
    var scroll := ScrollContainer.new()
    scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
    scroll.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
    root.add_child(scroll)
    var content := VBoxContainer.new()
    content.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    content.add_theme_constant_override("separation", 10)
    scroll.add_child(content)
    return content
