extends Control

signal navigate(id: String, args: Dictionary)

const UIKit = preload("res://scripts/ui/ui_kit.gd")

var args: Dictionary = {}


func _ready() -> void:
    var c := UIKit.screen_base(self, "CONFIGURACIÓN")
    var s: Dictionary = SaveManager.data["settings"]
    var q := UIKit.option(["BAJO (resolución 60%, sin sombras)", "MEDIO (80%, sombras)", "ALTO (100%, MSAA 2x, sombras)"], int(s["quality"]))
    c.add_child(UIKit.row("Calidad gráfica", q))
    var fps := UIKit.option(["30 FPS", "60 FPS"], 1 if int(s["fps"]) == 60 else 0)
    c.add_child(UIKit.row("Límite de FPS", fps))
    var sc := HSlider.new()
    sc.min_value = 0.7
    sc.max_value = 1.4
    sc.step = 0.05
    sc.value = float(s["btn_scale"])
    sc.custom_minimum_size = Vector2(0, 40)
    c.add_child(UIKit.row("Tamaño botones", sc))
    var edit := CheckBox.new()
    edit.text = "Editar posición de botones (arrastra durante el combate)"
    edit.button_pressed = bool(s.get("edit_controls", false))
    c.add_child(edit)
    var op := HSlider.new()
    op.min_value = 0.3
    op.max_value = 1.0
    op.step = 0.05
    op.value = float(s["opacity"])
    op.custom_minimum_size = Vector2(0, 40)
    c.add_child(UIKit.row("Transparencia", op))
    var info := UIKit.label("", 15, Color("#9fb7d9"))
    c.add_child(info)
    var save := UIKit.button("APLICAR Y GUARDAR", Color("#22A879"), 56, 18)
    save.pressed.connect(func():
        s["quality"] = q.selected
        s["fps"] = 60 if fps.selected == 1 else 30
        s["btn_scale"] = sc.value
        s["opacity"] = op.value
        s["edit_controls"] = edit.button_pressed
        SaveManager.save()
        GameManager.apply_settings()
        info.text = "Guardado.")
    c.add_child(save)
    var reset := UIKit.button("RESTAURAR CONTROLES", Color("#BC4F5D"), 48, 16)
    reset.pressed.connect(func():
        sc.value = 1.0
        op.value = 0.7
        edit.button_pressed = false
        s["button_positions"] = {}
        SaveManager.save())
    c.add_child(reset)
