extends Node

var selected_char := 0
var battle_config: Dictionary = {}

var DIFFICULTIES: Array = ["Muy fácil", "Fácil", "Normal", "Difícil", "Experto"]

var CHARACTERS: Array = [
    {"name": "KAEL", "role": "Equilibrado", "color": Color("#3a8dff"), "hp": 1.0, "speed": 1.0, "power": 1.0, "energy": 100.0, "fly": true, "scale": 1.0, "blast": 1.0},
    {"name": "BRAKKA", "role": "Fuerza", "color": Color("#d9482b"), "hp": 1.3, "speed": 0.85, "power": 1.4, "energy": 90.0, "fly": true, "scale": 1.15, "blast": 0.8},
    {"name": "ZEPHYRA", "role": "Velocidad", "color": Color("#3ee0c3"), "hp": 0.85, "speed": 1.35, "power": 0.8, "energy": 110.0, "fly": true, "scale": 0.9, "blast": 0.9},
    {"name": "ORIN", "role": "Energía", "color": Color("#b05cff"), "hp": 0.9, "speed": 1.0, "power": 0.8, "energy": 140.0, "fly": true, "scale": 1.0, "blast": 1.5},
    {"name": "SYLAS", "role": "Técnico", "color": Color("#f2c14e"), "hp": 1.0, "speed": 1.1, "power": 1.0, "energy": 100.0, "fly": true, "scale": 1.0, "blast": 1.0},
    {"name": "MOGRA", "role": "Defensivo", "color": Color("#5f8f5a"), "hp": 1.4, "speed": 0.9, "power": 0.9, "energy": 100.0, "fly": true, "scale": 1.1, "blast": 0.9, "defense": 0.6},
    {"name": "VEXA", "role": "Larga distancia", "color": Color("#ff7aa8"), "hp": 0.85, "speed": 1.0, "power": 0.7, "energy": 130.0, "fly": true, "scale": 0.95, "blast": 1.4},
    {"name": "IGNAR", "role": "Explosivo", "color": Color("#ff8a1f"), "hp": 0.95, "speed": 1.0, "power": 1.1, "energy": 100.0, "fly": true, "scale": 1.05, "blast": 1.3},
    {"name": "TITANOR", "role": "Gigante", "color": Color("#8d8d9c"), "hp": 1.8, "speed": 0.7, "power": 1.6, "energy": 100.0, "fly": true, "scale": 1.6, "blast": 1.0},
    {"name": "DORN", "role": "Terrestre", "color": Color("#c58b35"), "hp": 1.25, "speed": 1.15, "power": 1.25, "energy": 100.0, "fly": false, "scale": 1.05, "blast": 0.8}
]

var ARENAS: Array = [
    {"name": "Llanura rocosa", "ground": Color("#6b6358"), "sky_top": Color("#2a5ea8"), "sky_hor": Color("#cfe3ff"), "rocks": true, "ringout": false},
    {"name": "Desierto", "ground": Color("#c9a25a"), "sky_top": Color("#4a8fd8"), "sky_hor": Color("#ffe7b8"), "rocks": true, "ringout": false},
    {"name": "Ciudad futurista", "ground": Color("#2a3350"), "sky_top": Color("#140a33"), "sky_hor": Color("#6a3fb0"), "rocks": false, "ringout": false},
    {"name": "Terreno volcánico", "ground": Color("#2b1d1a"), "sky_top": Color("#3a0d08"), "sky_hor": Color("#ff7a2a"), "rocks": true, "ringout": false},
    {"name": "Arena flotante", "ground": Color("#4a5d8f"), "sky_top": Color("#0b1b4a"), "sky_hor": Color("#8fb8ff"), "rocks": false, "ringout": true}
]

var STORY: Array = [
    {"title": "Cap. 1: Grieta en el Núcleo", "text": "El Núcleo Aether vibra y una grieta se abre sobre la llanura. Brakka, guardián del valle, cree que eres la causa y te bloquea el paso.", "enemy": 1, "arena": 0, "level": 1},
    {"title": "Cap. 2: Vientos del desierto", "text": "Zephyra, mensajera veloz, te reta: solo quien la alcance podrá cruzar el desierto hacia la ciudad.", "enemy": 2, "arena": 1, "level": 1},
    {"title": "Cap. 3: La decisión", "text": "Vexa, traidora del Consejo, dispara desde la distancia. Cuando caiga, decidirás su destino (elige la ruta antes de combatir).", "enemy": 6, "arena": 2, "level": 2,
        "choices": [{"label": "Ruta Clemencia", "branch": "mercy"}, {"label": "Ruta Dominio", "branch": "force"}]},
    {"title": "Cap. 4: Consecuencias", "text": "Tu decisión cambia el camino hacia el Núcleo: Clemencia lleva a Orin en la arena flotante; Dominio, a Ignar en el volcán.", "enemy": 4, "arena": 4, "level": 3,
        "branches": {"mercy": {"enemy": 3, "arena": 4, "level": 3}, "force": {"enemy": 7, "arena": 3, "level": 3}}},
    {"title": "Cap. 5: Núcleo Aether", "text": "Titanor, el último custodio, protege el corazón de la energía.", "enemy": 8, "arena": 3, "level": 3, "hp": 1.3,
        "ending": {"mercy": "FINAL CLEMENCIA: el Núcleo se calma y Vexa sella la grieta contigo.", "force": "FINAL DOMINIO: absorbes el Núcleo, pero el silencio que queda es tuyo."}}
]

func apply_settings() -> void:
    var s: Dictionary = SaveManager.data["settings"]
    var q: int = clampi(int(s["quality"]), 0, 2)
    var vp := get_viewport()
    vp.scaling_3d_scale = [0.6, 0.8, 1.0][q]
    vp.msaa_3d = [Viewport.MSAA_DISABLED, Viewport.MSAA_DISABLED, Viewport.MSAA_2X][q]
    Engine.max_fps = int(s["fps"])

func make_config(mode: String, p_char: int, e_char: int, arena: int, level: int) -> Dictionary:
    return {"mode": mode, "p_char": p_char, "e_char": e_char, "arena": arena, "level": level,
        "time": 99.0, "ai_mode": 1, "player_hp": 1.0, "enemy_hp": 1.0, "online": false,
        "round": 1, "chapter": 0, "wave": 1}

func story_config(ch: int, p_char: int) -> Dictionary:
    if ch >= STORY.size():
        return {}
    var c: Dictionary = STORY[ch]
    var d: Dictionary = c
    if c.has("branches"):
        var br := str(SaveManager.data["branch"])
        d = c["branches"].get(br, c["branches"]["mercy"])
    var cfg := make_config("story", p_char, int(d["enemy"]), int(d["arena"]), int(d["level"]))
    cfg["chapter"] = ch
    cfg["enemy_hp"] = float(c.get("hp", 1.0))
    return cfg

func next_config(cfg: Dictionary) -> Dictionary:
    var mode := str(cfg.get("mode", ""))
    if mode == "tournament":
        var r := int(cfg["round"])
        if r >= 3:
            return {}
        var n: Dictionary = cfg.duplicate()
        n["round"] = r + 1
        n["e_char"] = randi() % CHARACTERS.size()
        n["level"] = mini(4, int(cfg["level"]) + 1)
        n["arena"] = randi() % ARENAS.size()
        return n
    if mode == "story":
        return story_config(int(cfg["chapter"]) + 1, int(cfg["p_char"]))
    return {}
