"""Genera los PNG de los mapas (cielos panoramicos + texturas de suelo).
Sin dependencias raras: solo numpy + Pillow.   Uso: python3 tools/gen_maps.py"""
import numpy as np
from PIL import Image

W, H = 1536, 768          # panorama equirectangular
G = 512                   # textura de suelo (tileable)
OUT = "assets/"


def fbm(h, w, beta=2.0, seed=0):
    """Ruido tileable por FFT (periodico en ambos ejes). Devuelve 0..1."""
    rng = np.random.default_rng(seed)
    n = rng.standard_normal((h, w))
    fy = np.fft.fftfreq(h)[:, None]
    fx = np.fft.fftfreq(w)[None, :]
    f = np.sqrt(fx * fx + fy * fy)
    f[0, 0] = 1.0
    spec = np.fft.fft2(n) / (f ** (beta / 2.0))
    spec[0, 0] = 0
    r = np.real(np.fft.ifft2(spec))
    r -= r.min()
    r /= r.max() + 1e-9
    return r


def col(hexs):
    hexs = hexs.lstrip("#")
    return np.array([int(hexs[i:i + 2], 16) for i in (0, 2, 4)], dtype=np.float32) / 255.0


def lerp(a, b, t):
    return a + (b - a) * t[..., None]


def smooth(x, a, b):
    t = np.clip((x - a) / (b - a), 0, 1)
    return t * t * (3 - 2 * t)


def profile(w, seed, base, amp, octaves=4):
    """Perfil 1D periodico (montanas / dunas)."""
    rng = np.random.default_rng(seed)
    x = np.arange(w) / w * 2 * np.pi
    p = np.zeros(w)
    for o in range(octaves):
        k = int(2 ** (o + 1)) + rng.integers(0, 3)
        p += np.sin(k * x + rng.uniform(0, 6.28)) * (amp / (1.7 ** o))
    return base + p


def sky_base(top, hor, below, power=0.6):
    y = np.linspace(0, 1, H)[:, None] * np.ones((1, W))
    up = np.clip(1 - y / 0.5, 0, 1) ** power       # 1 en horizonte -> 0 en cenit
    c = lerp(np.broadcast_to(top, (H, W, 3)).copy(), np.broadcast_to(hor, (H, W, 3)).copy(), 1 - up)
    dn = smooth(y, 0.5, 0.58)
    return lerp(c, np.broadcast_to(below, (H, W, 3)).copy(), dn)


def add_clouds(img, color, seed, cover=0.5, soft=0.18, zone=(0.05, 0.52), strength=0.9):
    n = fbm(H, W, 3.3, seed)
    m = smooth(n, cover, cover + soft)
    y = np.linspace(0, 1, H)[:, None]
    zmask = smooth(y, zone[0], zone[0] + 0.1) * (1 - smooth(y, zone[1] - 0.12, zone[1]))
    m = (m * zmask * strength)
    shade = fbm(H, W, 3.0, seed + 7)
    c = np.broadcast_to(color, (H, W, 3)) * (0.78 + 0.3 * shade[..., None])
    return img * (1 - m[..., None]) + np.clip(c, 0, 1) * m[..., None]


def add_sun(img, cx, cy, color, size=0.012, glow=0.25):
    yy, xx = np.mgrid[0:H, 0:W]
    dx = np.minimum(np.abs(xx - cx), W - np.abs(xx - cx)) / W * 2.0
    dy = (yy - cy) / H
    d = np.sqrt(dx * dx + dy * dy)
    core = smooth(1 - d / size, 0, 0.4)
    halo = np.exp(-(d / glow) ** 2) * 0.55
    m = np.clip(core + halo, 0, 1)
    return img * (1 - m[..., None]) + color * m[..., None]


def silhouette(img, prof, color, seed=0, haze=None, haze_amt=0.0, below_fill=False):
    hor = H // 2
    yy = np.arange(H)[:, None]
    top = hor - prof[None, :]
    mask = (yy >= top).astype(np.float32)
    if not below_fill:
        mask *= (yy <= hor + 2)
    c = np.broadcast_to(color, (H, W, 3)).copy()
    if haze is not None:
        t = np.clip((yy - top) / 220.0, 0, 1) * haze_amt
        c = c * (1 - t[..., None]) + haze * t[..., None]
    return img * (1 - mask[..., None]) + c * mask[..., None]


def save(arr, name):
    a = (np.clip(arr, 0, 1) * 255).astype(np.uint8)
    Image.fromarray(a, "RGB").save(OUT + name, optimize=True)
    print("ok", name, a.shape)


# ----------------------------------------------------------------- cielos
def sky_wasteland():          # 0 Llanura rocosa (estilo yermo de DBZ)
    img = sky_base(col("#1f55a8"), col("#bcd9f6"), col("#9a8a74"))
    img = add_sun(img, int(W * .22), int(H * .30), col("#fff6d8"), 0.014, 0.22)
    img = add_clouds(img, col("#ffffff"), 11, 0.52, 0.2, strength=0.95)
    haze = col("#c9c0b4")
    img = silhouette(img, np.clip(profile(W, 3, 34, 26, 5), 6, 400), col("#9a8f86"), haze=haze, haze_amt=0.55)
    # mesetas
    m = profile(W, 8, 24, 18, 4)
    m = m + 42 * smooth(np.sin(np.arange(W) / W * 2 * np.pi * 7), 0.15, 0.4)
    img = silhouette(img, np.clip(m, 4, 300), col("#7a6e62"), haze=haze, haze_amt=0.3)
    return img


def sky_desert():             # 1 Desierto
    img = sky_base(col("#3b82d6"), col("#ffe2ae"), col("#d8b570"), 0.5)
    img = add_sun(img, int(W * .6), int(H * .34), col("#fffbe6"), 0.02, 0.3)
    img = add_clouds(img, col("#fff4de"), 21, 0.6, 0.2, strength=0.6)
    haze = col("#f2d9a3")
    img = silhouette(img, np.clip(profile(W, 5, 20, 16, 3), 4, 120), col("#e0b872"), haze=haze, haze_amt=0.5)
    img = silhouette(img, np.clip(profile(W, 9, 9, 8, 3), 2, 60), col("#cfa25a"), haze=haze, haze_amt=0.2)
    return img


def sky_city():               # 2 Ciudad futurista (atardecer neon)
    img = sky_base(col("#0d0627"), col("#8a45c8"), col("#190d3a"), 0.7)
    rng = np.random.default_rng(4)
    yy, xx = np.mgrid[0:H, 0:W]
    stars = (rng.random((H, W)) > 0.9985) * smooth(1 - yy / (H * 0.4), 0, 1)
    img = img + stars[..., None] * 0.9
    img = add_clouds(img, col("#d070e8"), 31, 0.58, 0.2, zone=(0.15, 0.5), strength=0.5)
    img = add_sun(img, int(W * .75), int(H * .42), col("#ff9ad8"), 0.02, 0.2)
    hor = H // 2
    for layer, (cnt, hmin, hmax, c) in enumerate([(70, 40, 190, "#2a1856"), (90, 30, 140, "#1a0f3a"), (110, 20, 90, "#0f0824")]):
        prof = np.zeros(W)
        x = 0
        while x < W:
            bw = int(rng.integers(10, 38)); bh = int(rng.integers(hmin, hmax))
            prof[x:x + bw] = bh
            x += bw + int(rng.integers(0, 6))
        img = silhouette(img, prof, col(c))
        # ventanas encendidas
        yy2 = np.arange(H)[:, None]; top = hor - prof[None, :]
        win = (rng.random((H, W)) > 0.93) & (yy2 >= top + 4) & (yy2 <= hor) & (prof[None, :] > 0)
        win &= ((yy2 % 6) < 2) & ((np.arange(W)[None, :] % 5) < 2)
        wc = np.where(rng.random((H, W, 1)) > 0.5, col("#ffd27a"), col("#7af0ff"))
        img = np.where(win[..., None], wc * (0.7 - 0.15 * layer), img)
    # franja de neon en el horizonte
    glow = np.exp(-((np.arange(H)[:, None] - hor + 6) / 16.0) ** 2) * 0.35
    return img + glow[..., None] * col("#ff4fd8")


def sky_volcano():            # 3 Terreno volcanico
    img = sky_base(col("#2a0804"), col("#ff7a2a"), col("#3a1208"), 0.55)
    img = add_clouds(img, col("#1a0a08"), 41, 0.45, 0.22, zone=(0.05, 0.5), strength=0.95)
    img = add_clouds(img, col("#ff9a50"), 42, 0.66, 0.15, zone=(0.3, 0.52), strength=0.45)
    img = add_sun(img, int(W * .4), int(H * .40), col("#ffd28a"), 0.016, 0.28)
    haze = col("#d4501c")
    img = silhouette(img, np.clip(profile(W, 6, 56, 44, 5), 6, 420), col("#2a1410"), haze=haze, haze_amt=0.6)
    # volcanes con cono
    prof = np.zeros(W)
    for cx, hh, ww in [(int(W * .15), 250, 170), (int(W * .62), 320, 210), (int(W * .88), 200, 140)]:
        xs = np.arange(W); d = np.minimum(abs(xs - cx), W - abs(xs - cx))
        prof = np.maximum(prof, np.clip(hh * (1 - d / ww), 0, None))
    img = silhouette(img, prof, col("#1a0b09"), haze=haze, haze_amt=0.45)
    hor = H // 2
    # lava brillando en la base
    glow = np.exp(-((np.arange(H)[:, None] - hor + 4) / 14.0) ** 2) * 0.7
    return img + glow[..., None] * col("#ff6a1a")


def sky_floating():           # 4 Arena flotante (mar de nubes + islas)
    img = sky_base(col("#071544"), col("#7fb0ff"), col("#cfe2ff"), 0.6)
    rng = np.random.default_rng(5)
    yy, xx = np.mgrid[0:H, 0:W]
    stars = (rng.random((H, W)) > 0.998) * smooth(1 - yy / (H * 0.35), 0, 1)
    img = img + stars[..., None]
    img = add_sun(img, int(W * .35), int(H * .32), col("#ffffff"), 0.016, 0.26)
    img = add_clouds(img, col("#ffffff"), 51, 0.55, 0.2, zone=(0.1, 0.5), strength=0.7)
    # mar de nubes bajo el horizonte
    n = fbm(H, W, 2.4, 52)
    sea = lerp(np.broadcast_to(col("#e8f1ff"), (H, W, 3)).copy(), np.broadcast_to(col("#9ab8ee"), (H, W, 3)).copy(), n)
    m = smooth(yy / H, 0.5, 0.53)
    img = img * (1 - m[..., None]) + sea * m[..., None]
    # islas flotantes lejanas
    for _ in range(9):
        cx = int(rng.integers(0, W)); cy = int(rng.integers(int(H * .28), int(H * .46)))
        rw = int(rng.integers(26, 70)); rh = int(rw * .22)
        dx = np.minimum(abs(xx - cx), W - abs(xx - cx))
        top = ((dx / rw) ** 2 + ((yy - cy) / rh) ** 2) < 1
        under = (yy > cy) & (dx < rw * (1 - (yy - cy) / (rh * 3.2))) & (yy < cy + rh * 3.2)
        img = np.where(top[..., None], col("#6f9a6a"), img)
        img = np.where(under[..., None], col("#6a6f86"), img)
    return img


# ----------------------------------------------------------------- suelos
def ground_rock():
    n1, n2, n3 = fbm(G, G, 2.2, 61), fbm(G, G, 1.2, 62), fbm(G, G, 3.0, 63)
    base = lerp(np.broadcast_to(col("#5b5349"), (G, G, 3)).copy(), np.broadcast_to(col("#8b8174"), (G, G, 3)).copy(), n1)
    crack = 1 - smooth(np.abs(n2 - 0.5), 0.0, 0.018)
    img = base * (0.85 + 0.3 * n3[..., None]) * (1 - 0.65 * crack[..., None])
    return img


def ground_sand():
    n = fbm(G, G, 2.4, 71)
    yy, xx = np.mgrid[0:G, 0:G]
    ripple = 0.5 + 0.5 * np.sin((xx / G * 2 * np.pi * 10) + n * 9.0)
    base = lerp(np.broadcast_to(col("#c4974c"), (G, G, 3)).copy(), np.broadcast_to(col("#ecc87e"), (G, G, 3)).copy(), ripple * 0.6 + n * 0.4)
    grain = fbm(G, G, 0.2, 72)
    return base * (0.93 + 0.14 * grain[..., None])


def ground_city():
    n = fbm(G, G, 2.0, 81)
    base = lerp(np.broadcast_to(col("#161b2e"), (G, G, 3)).copy(), np.broadcast_to(col("#2a3350"), (G, G, 3)).copy(), n)
    yy, xx = np.mgrid[0:G, 0:G]
    cell = G // 4
    line = ((xx % cell) < 3) | ((yy % cell) < 3)
    neon = np.where(line[..., None], col("#46d8ff") * 0.85, 0)
    seam = (((xx + cell // 2) % cell) < 1) & ((yy // (cell // 2)) % 2 == 0)
    return base + neon * 0.9 + seam[..., None] * col("#8a6cff") * 0.35


def ground_lava():
    n1, n2 = fbm(G, G, 2.2, 91), fbm(G, G, 1.4, 92)
    base = lerp(np.broadcast_to(col("#1a1210"), (G, G, 3)).copy(), np.broadcast_to(col("#3a2a24"), (G, G, 3)).copy(), n1)
    vein = 1 - smooth(np.abs(n2 - 0.5), 0.0, 0.03)
    glow = lerp(np.broadcast_to(col("#ff5a12"), (G, G, 3)).copy(), np.broadcast_to(col("#ffd070"), (G, G, 3)).copy(), vein ** 3)
    return base * (1 - vein[..., None]) + glow * vein[..., None]


def ground_tiles():
    n = fbm(G, G, 2.0, 101)
    yy, xx = np.mgrid[0:G, 0:G]
    cell = G // 4
    tid = ((xx // cell) + (yy // cell)) % 2
    base = np.where(tid[..., None] == 0, col("#8f99b4"), col("#7a84a2")) * (0.92 + 0.16 * n[..., None])
    edge = ((xx % cell) < 3) | ((yy % cell) < 3)
    base = np.where(edge[..., None], col("#4a5272"), base)
    scratch = fbm(G, G, 0.8, 102)
    return base * (0.95 + 0.1 * scratch[..., None])


if __name__ == "__main__":
    for i, (s, g) in enumerate([(sky_wasteland, ground_rock), (sky_desert, ground_sand), (sky_city, ground_city), (sky_volcano, ground_lava), (sky_floating, ground_tiles)]):
        save(s(), "sky_%d.png" % i)
        save(g(), "ground_%d.png" % i)
